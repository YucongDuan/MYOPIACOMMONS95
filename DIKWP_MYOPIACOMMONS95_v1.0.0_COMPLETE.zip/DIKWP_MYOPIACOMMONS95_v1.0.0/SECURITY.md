# Security

- The core can run offline with the Python standard library.
- The reference HTTP service binds only to loopback addresses and exposes GET endpoints only.
- No telemetry, analytics, external scripts, model API, cloud upload, email, payment, or device-control integration is enabled by default.
- Outcome, adverse-event, and consent records can be written to append-only hash-chain ledgers through an explicit local command.
- Users should store identifiable health data on encrypted devices, maintain backups, restrict filesystem permissions, and follow applicable health-data law.
- Do not expose the reference server directly to a public network. A production deployment requires authentication, encryption in transit, authorization, audit logging, incident response, backup, and jurisdiction-specific privacy review.
