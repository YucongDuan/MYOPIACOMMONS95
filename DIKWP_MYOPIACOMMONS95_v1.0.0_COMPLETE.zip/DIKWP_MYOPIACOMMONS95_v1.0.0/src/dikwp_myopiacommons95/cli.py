from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from . import EVIDENCE_SNAPSHOT, SYSTEM_NAME, SYSTEM_TITLE, __version__
from .audit import audit_claim, audit_claims
from .compiler import compile_profile
from .demo import run_demo
from .evidence import evidence_registry, intervention_registry
from .ledger import append_record, verify_ledger
from .server import serve
from .utils import has_cjk, read_json, write_json
from .verify import verify_output


def _print(value) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def doctor() -> dict:
    package_dir = Path(__file__).resolve().parent
    cjk_files = []
    for path in package_dir.rglob("*"):
        if path.is_file() and path.suffix in {".py", ".md", ".json", ".html", ".txt"}:
            try:
                if has_cjk(path.read_text(encoding="utf-8")):
                    cjk_files.append(path.name)
            except UnicodeDecodeError:
                pass
    return {
        "system": SYSTEM_NAME,
        "title": SYSTEM_TITLE,
        "version": __version__,
        "evidence_snapshot": EVIDENCE_SNAPSHOT,
        "python_standard_library_core": True,
        "evidence_record_count": len(evidence_registry()),
        "intervention_class_count": len(intervention_registry()),
        "english_only_package_scan_passed": not cjk_files,
        "cjk_files": sorted(cjk_files),
        "automatic_diagnosis_authority": 0,
        "automatic_prescription_authority": 0,
        "automatic_device_control_authority": 0,
        "automatic_external_action_authority": 0,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="myopiacommons95", description=SYSTEM_TITLE)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    demo = sub.add_parser("demo")
    demo.add_argument("--out", required=True)
    compile_cmd = sub.add_parser("compile")
    compile_cmd.add_argument("--profile", required=True)
    compile_cmd.add_argument("--out", required=True)
    verify_cmd = sub.add_parser("verify")
    verify_cmd.add_argument("--out", required=True)
    claim = sub.add_parser("audit-claim")
    claim.add_argument("text")
    claim_file = sub.add_parser("audit-file")
    claim_file.add_argument("--file", required=True)
    claim_file.add_argument("--out")
    sub.add_parser("evidence")
    sub.add_parser("interventions")
    ledger_append = sub.add_parser("ledger-append")
    ledger_append.add_argument("--ledger", required=True)
    ledger_append.add_argument("--record-type", required=True)
    ledger_append.add_argument("--payload", required=True)
    ledger_verify = sub.add_parser("ledger-verify")
    ledger_verify.add_argument("--ledger", required=True)
    server = sub.add_parser("serve")
    server.add_argument("--out", required=True)
    server.add_argument("--host", default="127.0.0.1")
    server.add_argument("--port", type=int, default=8799)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "doctor":
        result = doctor()
        _print(result)
        return 0 if result["english_only_package_scan_passed"] else 1
    if args.command == "demo":
        _print(run_demo(args.out))
        return 0
    if args.command == "compile":
        result = compile_profile(args.profile, args.out)
        _print({"out_dir": result["out_dir"], "compile_id": result["bundle"]["compile_id"]})
        return 0
    if args.command == "verify":
        result = verify_output(args.out)
        _print(result)
        return 0 if result["valid"] else 1
    if args.command == "audit-claim":
        _print(audit_claim(args.text))
        return 0
    if args.command == "audit-file":
        payload = read_json(args.file)
        claims = payload["claims"] if isinstance(payload, dict) else payload
        result = audit_claims(claims)
        if args.out:
            write_json(args.out, result)
        _print(result)
        return 0
    if args.command == "evidence":
        _print(evidence_registry())
        return 0
    if args.command == "interventions":
        _print(intervention_registry())
        return 0
    if args.command == "ledger-append":
        _print(append_record(args.ledger, read_json(args.payload), args.record_type))
        return 0
    if args.command == "ledger-verify":
        result = verify_ledger(args.ledger)
        _print(result)
        return 0 if result["valid"] else 1
    if args.command == "serve":
        serve(args.out, args.host, args.port)
        return 0
    raise RuntimeError("unknown command")
