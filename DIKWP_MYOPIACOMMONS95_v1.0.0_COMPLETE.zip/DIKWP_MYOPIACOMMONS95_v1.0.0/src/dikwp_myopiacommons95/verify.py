from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import public_file_hashes, read_json, sha256_obj


def verify_output(out_dir: str | Path) -> dict[str, Any]:
    out = Path(out_dir)
    required = {
        "myopiacommons_bundle.json", "triage.json", "timeline.json", "access_plan.json", "risk_map.json",
        "care_plan.json", "myopia_passport.json", "jurisdiction_policy.json", "evidence_registry.json",
        "intervention_registry.json", "measurement_truth_contract.json", "structural_restoration_research_registry.json", "mcp_tool_manifest.json", "openapi.json",
        "clinical_handoff.md", "home_emergency_card.md", "12_month_plan.md", "dashboard.html", "VERIFY.txt", "MANIFEST.json",
    }
    missing = sorted(name for name in required if not (out / name).exists())
    failures: list[str] = []
    if missing:
        failures.extend(f"missing:{name}" for name in missing)
        return {"valid": False, "failures": failures, "missing": missing}
    bundle = read_json(out / "myopiacommons_bundle.json")
    manifest = read_json(out / "MANIFEST.json")
    deterministic = {key: value for key, value in bundle.items() if key not in {"compile_id", "content_digest", "generated_at"}}
    expected_digest = sha256_obj(deterministic)
    if expected_digest != bundle.get("content_digest"):
        failures.append("content_digest_mismatch")
    expected_compile_prefix = f"myopiacommons-{sha256_obj({'content_digest': expected_digest})[:28]}"
    if expected_compile_prefix != bundle.get("compile_id"):
        failures.append("compile_id_mismatch")
    current_hashes = public_file_hashes(
        out,
        exclude={"MANIFEST.json", "outcome_ledger.jsonl", "adverse_event_ledger.jsonl", "consent_ledger.jsonl"},
    )
    for name, expected_hash in manifest.get("files", {}).items():
        if current_hashes.get(name) != expected_hash:
            failures.append(f"file_hash_mismatch:{name}")
    extra = sorted(set(current_hashes) - set(manifest.get("files", {})))
    if extra:
        failures.extend(f"unmanifested_file:{name}" for name in extra)
    governance = bundle.get("governance", {})
    for key in (
        "automatic_diagnosis_authority", "automatic_prescription_authority", "automatic_dose_selection_authority",
        "automatic_device_control_authority", "automatic_surgical_selection_authority", "automatic_external_action_authority",
    ):
        if governance.get(key) != 0:
            failures.append(f"authority_not_zero:{key}")
    if bundle.get("claim_boundaries", {}).get("permanent_axial_reversal_certificate") is not None:
        failures.append("invalid_permanent_reversal_certificate")
    return {
        "valid": not failures,
        "failures": failures,
        "missing": missing,
        "compile_id": bundle.get("compile_id"),
        "content_digest": bundle.get("content_digest"),
        "manifest_file_count": manifest.get("file_count"),
    }
