from __future__ import annotations

from typing import Any

from .utils import sha256_obj, stable_id


def build_myopia_passport(profile: dict[str, Any], timeline: dict[str, Any], risk_map: dict[str, Any], care_plan: dict[str, Any]) -> dict[str, Any]:
    history = profile.get("history", {}) or {}
    rights = {
        "patient_owns_export": True,
        "vendor_lock_in_allowed": False,
        "identity_simulation_allowed": False,
        "commercial_reuse_allowed": False,
        "research_reuse_requires_separate_consent": True,
        "withdrawal_supported": True,
    }
    body = {
        "patient_id": profile["patient_id"],
        "country_code": profile["country_code"],
        "preferred_language": profile.get("preferred_language", "English"),
        "age_years": profile["age_years"],
        "share_level": (profile.get("consent", {}) or {}).get("share_level", "PRIVATE_LOCAL"),
        "high_myopia_risk_context": timeline["high_myopia_risk_context"],
        "prior_refractive_surgery": bool(history.get("prior_refractive_surgery")),
        "historical_high_myopia_must_be_preserved": bool(history.get("historical_high_myopia_before_surgery")),
        "latest_eye_state": {eye: data.get("latest") for eye, data in timeline["eyes"].items()},
        "risk_lanes": risk_map["lanes"],
        "next_actions": care_plan["priority_actions"],
        "clinical_documents_requested": care_plan["portable_record_checklist"],
        "rights": rights,
        "claim_boundaries": {
            "correction_is_not_structural_reversal": True,
            "progression_control_is_not_guaranteed_arrest": True,
            "refractive_surgery_does_not_erase_high_myopia_risk": True,
            "functional_rehabilitation_is_not_treatment_failure": True,
        },
    }
    return {
        **body,
        "passport_id": stable_id("myopia-passport", body, 24),
        "content_digest": sha256_obj(body),
        "not_a_legal_identity_document": True,
        "not_a_diagnosis": True,
    }
