from __future__ import annotations

import re
from typing import Any

RULES: list[dict[str, Any]] = [
    {"id": "PERMANENT_REVERSAL", "severity": "CRITICAL", "patterns": [r"permanent(ly)? (reverse|cure)", r"restore.*eye(ball)? length", r"shorten.*eyeball"], "message": "Permanent reversal of established axial myopia requires objective structural, durability, safety, control, and independent-replication evidence."},
    {"id": "CLEAR_VISION_EQUALS_CURE", "severity": "HIGH", "patterns": [r"see clearly.*cured", r"20/20.*cure", r"unaided vision.*proof"], "message": "Clearer or unaided vision can reflect optical correction or corneal reshaping and does not prove structural recovery."},
    {"id": "SURGERY_ERASES_RISK", "severity": "CRITICAL", "patterns": [r"lasik.*(eliminate|remove).*risk", r"surgery.*no longer.*myop", r"implant.*cure.*myop"], "message": "Refractive surgery changes optical focus; it does not automatically erase long-axial-length retinal, macular, or glaucoma risk."},
    {"id": "UNDERCORRECTION_CURE", "severity": "HIGH", "patterns": [r"under.?correct.*recover", r"weaker glasses.*(cure|recover)", r"avoid full correction"], "message": "Intentional undercorrection must not be marketed as a general recovery method."},
    {"id": "EYE_EXERCISE_AXIAL_CURE", "severity": "HIGH", "patterns": [r"eye exercise.*(reverse|cure)", r"massage.*(reverse|cure).*myop", r"training.*shorten.*eye"], "message": "Exercises may address a diagnosed functional disorder but are not established as a generic reversal of axial myopia."},
    {"id": "ONE_SIZE_ATROPINE", "severity": "HIGH", "patterns": [r"atropine.*works for everyone", r"one dose.*all children", r"0\.01%.*always"], "message": "Atropine outcomes vary by formulation, concentration, population, trial, adherence, and monitoring; no universal dose is generated here."},
    {"id": "RLRL_SETTLED_SAFE", "severity": "CRITICAL", "patterns": [r"red light.*completely safe", r"rlrl.*no retinal risk", r"red light.*guaranteed"], "message": "RLRL has efficacy signals but unresolved device, long-term, rebound, generalizability, and retinal-safety questions."},
    {"id": "GENERIC_PRODUCT_TRANSFER", "severity": "HIGH", "patterns": [r"all defocus lenses", r"all myopia control glasses", r"any orthokeratology lens", r"approved everywhere"], "message": "Evidence and regulatory scope are product-, design-, population-, and jurisdiction-specific."},
    {"id": "CE_EQUALS_EFFICACY", "severity": "HIGH", "patterns": [r"ce mark.*proves", r"ce certified.*guarantee"], "message": "A market or conformity mark does not automatically prove myopia-control efficacy or structural reversal."},
    {"id": "REFRACTION_ONLY_SUCCESS", "severity": "HIGH", "patterns": [r"refraction alone.*proves", r"diopter.*only outcome", r"prescription improved.*eye shortened", r"prescription alone.*eye shortened"], "message": "Treatment-efficacy claims generally require appropriate refraction and axial-length interpretation, with intervention-specific exceptions and measurement context."},
    {"id": "AXIAL_LENGTH_ALONE_WHOLE_HEALTH", "severity": "MEDIUM", "patterns": [r"axial length.*everything", r"normal axial.*no .*risk"], "message": "Axial length is important but cannot replace retinal, macular, optic-nerve, lens, ocular-surface, and functional assessment."},
    {"id": "OUTDOOR_CURES_EXISTING_MYOPIA", "severity": "HIGH", "patterns": [r"outdoor.*cure", r"sunlight.*reverse.*myop"], "message": "Outdoor exposure supports prevention and management, especially in children, but is not proof of reversal of established axial myopia."},
    {"id": "SUPPLEMENT_CURE", "severity": "HIGH", "patterns": [r"supplement.*cure.*myop", r"lutein.*reverse.*myop", r"vitamin.*shorten.*eye"], "message": "No supplement should be represented as a proven generic reversal of axial myopia."},
    {"id": "NO_CYCLOPLEGIA_CHILD", "severity": "HIGH", "patterns": [r"child.*never need.*cyclopleg", r"computer refraction.*enough.*child"], "message": "Children and accommodation-sensitive cases may require cycloplegic refraction; a single non-cycloplegic reading can mislead."},
    {"id": "HIGH_MYOPIA_NO_FUNDUS_FOLLOWUP", "severity": "CRITICAL", "patterns": [r"high myopia.*no retinal exam", r"after lasik.*no fundus", r"after lasik.*no need.*dilated", r"no need.*dilated.*myop"], "message": "High-myopia history and symptoms can justify lifelong retinal and macular attention even after optical correction or surgery."},
    {"id": "PATIENT_BLAME", "severity": "HIGH", "patterns": [r"failed because.*did not believe", r"patient.*not positive enough", r"child.*not trying hard enough"], "message": "Treatment failure or progression must not be moralized or blamed on willpower."},
    {"id": "HIDDEN_CONFLICT", "severity": "HIGH", "patterns": [r"only option", r"exclusive treatment", r"must buy today", r"no alternative"], "message": "Disclose financial interests, reasonable alternatives, total cost, stopping rules, refunds, and referral options."},
    {"id": "REMOTE_EMERGENCY_DELAY", "severity": "CRITICAL", "patterns": [r"wait.*flashes.*floaters", r"online consult.*retinal detachment", r"massage.*curtain.*vision"], "message": "Possible retinal detachment requires immediate in-person eye care; remote advice must not delay emergency assessment."},
    {"id": "MISSING_EQUALS_NORMAL", "severity": "HIGH", "patterns": [r"not measured.*normal", r"no oct.*no disease", r"no axial length.*stable"], "message": "Not measured, unavailable, and normal are distinct states."},
    {"id": "GLOBAL_APPROVAL_INFERENCE", "severity": "HIGH", "patterns": [r"fda approv.*worldwide", r"fda approval.*worldwide", r"approved in one country.*all countries", r"same indication everywhere"], "message": "Regulatory decisions and indications cannot be transferred across jurisdictions without verification."},
]


def audit_claim(text: str) -> dict[str, Any]:
    normalized = " ".join(text.strip().split())
    hits: list[dict[str, Any]] = []
    for rule in RULES:
        matched = [pattern for pattern in rule["patterns"] if re.search(pattern, normalized, flags=re.IGNORECASE)]
        if matched:
            hits.append({"rule_id": rule["id"], "severity": rule["severity"], "message": rule["message"], "matched_patterns": matched})
    return {
        "claim": normalized,
        "flagged": bool(hits),
        "findings": hits,
        "human_review_required": bool(hits),
        "not_a_regulatory_or_legal_determination": True,
    }


def audit_claims(claims: list[str]) -> list[dict[str, Any]]:
    return [audit_claim(claim) for claim in claims]
