from __future__ import annotations

from typing import Any


def structural_restoration_research_registry() -> list[dict[str, Any]]:
    common = {
        "clinical_availability": "RESEARCH_ONLY",
        "permanent_reversal_certificate": None,
        "required_truth_conditions": [
            "objective structural change beyond measurement uncertainty",
            "separation from corneal, accommodative, choroidal, hydration, and diurnal effects",
            "appropriate control and masking where feasible",
            "durability after withdrawal",
            "preserved or improved visual function",
            "retinal, macular, optic-nerve, corneal, and systemic safety",
            "complete adverse-event and dropout reporting",
            "independent replication",
            "acceptable patient burden and access implications",
        ],
    }
    hypotheses = [
        ("SCLERAL_ECM_REBALANCING", "Can scleral extracellular-matrix remodeling be modified safely without weakening the globe or harming posterior tissues?"),
        ("RETINA_CHOROID_SCLERA_SIGNALING", "Which retinal, choroidal, and scleral signals are causal drivers of ocular growth rather than correlates?"),
        ("POSTERIOR_BIOMECHANICAL_LOAD", "Can posterior biomechanical stress be redistributed without creating new retinal or optic-nerve risk?"),
        ("AGE_AND_PLASTICITY_WINDOWS", "Which developmental or adult plasticity windows allow durable structural change?"),
        ("CIRCADIAN_AND_SPECTRAL_CAUSALITY", "Which timing and spectral effects are causal, safe, and generalizable across populations?"),
        ("PERSONAL_RESPONSE_PREDICTION", "Can response and adverse-event risk be predicted before costly or irreversible exposure?"),
        ("OPEN_NEGATIVE_RESULT_COMMONS", "Can shared outcome definitions and mandatory negative-result reporting reduce repeated ineffective treatment?"),
    ]
    return [{"id": identifier, "research_question": question, **common} for identifier, question in hypotheses]
