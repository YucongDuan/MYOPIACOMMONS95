from __future__ import annotations

import html
import json
from typing import Any


def render_clinical_handoff(bundle: dict[str, Any]) -> str:
    profile = bundle["profile"]
    triage = bundle["triage"]
    timeline = bundle["timeline"]
    care = bundle["care_plan"]
    lines = [
        "# DIKWP-MYOPIACOMMONS95 Clinical Handoff",
        "",
        "> Decision support only. This document is not a diagnosis, prescription, regulatory determination, or emergency service.",
        "",
        f"- Patient identifier: `{profile['patient_id']}`",
        f"- Age: {profile['age_years']}",
        f"- Country code: {profile['country_code']}",
        f"- Preferred language: {profile.get('preferred_language', 'English')}",
        f"- Urgency: **{triage['urgency']}**",
        f"- High-myopia risk context: **{timeline['high_myopia_risk_context']}**",
        "",
        "## Urgency reasons",
    ]
    if triage["reasons"]:
        lines.extend(f"- {item}" for item in triage["reasons"])
    else:
        lines.append("- No entered field triggered an emergency reason; missing information cannot rule out disease.")
    lines.extend(["", "## Priority actions"])
    lines.extend(f"- {item}" for item in care["priority_actions"])
    lines.extend(["", "## Latest per-eye data"])
    for eye_code, eye in timeline["eyes"].items():
        latest = eye.get("latest")
        lines.append(f"### {eye_code.upper()}")
        if not latest:
            lines.append("- No comparable measurement entered.")
            continue
        for key, value in latest.items():
            lines.append(f"- {key}: {value}")
        lines.append(f"- Annualized spherical-equivalent change: {eye.get('annualized_spherical_equivalent_change_d_per_year')}")
        lines.append(f"- Annualized axial-length change: {eye.get('annualized_axial_length_change_mm_per_year')}")
    lines.extend(["", "## Requested baseline and missing-data closure"])
    lines.extend(f"- **{item['item']}** — {item['purpose']}" for item in care["baseline_assessment"])
    lines.extend(["", "## Patient priorities"])
    goals = profile.get("goals", []) or []
    lines.extend(f"- {goal}" for goal in goals) if goals else lines.append("- Not yet recorded.")
    lines.extend(["", "## Authority boundary"])
    lines.extend([
        "- No automatic diagnosis.",
        "- No automatic prescription or dose selection.",
        "- No automatic device exposure or surgical selection.",
        "- A qualified human eye-care professional must examine and decide where clinical action is required.",
    ])
    return "\n".join(lines) + "\n"


def render_emergency_card(bundle: dict[str, Any]) -> str:
    return """# Myopia Safety Card

## Seek immediate eye care now for

- A sudden increase in floaters.
- New flashes of light.
- A curtain, fixed shadow, or missing area of vision.
- Sudden or rapidly worsening vision loss.
- Penetrating or high-speed eye trauma.
- Chemical exposure to the eye.

Do not delay possible retinal-detachment care for massage, exercises, red-light exposure, contact-lens wear, online advice, or a routine appointment. Do not drive yourself. For chemical exposure, begin continuous clean-water irrigation while obtaining emergency help.

## Seek same-day qualified care for

- New central distortion, a central blind spot, or rapid one-eye central blur.
- Contact-lens wear with pain, redness, light sensitivity, discharge, or sudden blur.
- Severe eye pain or a red light-sensitive eye.

This card does not rule out other emergencies and is not a diagnosis.
"""


def render_twelve_month_plan(bundle: dict[str, Any]) -> str:
    care = bundle["care_plan"]
    lines = [
        "# Twelve-Month Myopia Care and Vision-Protection Plan",
        "",
        "> The schedule is a planning scaffold. Urgent symptoms override every calendar date, and a qualified clinician determines examination and treatment frequency.",
        "",
    ]
    for phase in care["time_phases"]:
        lines.append(f"## {phase['phase'].replace('_', ' ')}")
        lines.extend(f"- {item}" for item in phase["objectives"])
        lines.append("")
    lines.extend(["## Outcome contract"])
    for key, value in care["review_contract"].items():
        lines.append(f"- {key.replace('_', ' ')}: {value}")
    return "\n".join(lines) + "\n"


def _badge(text: str, kind: str = "neutral") -> str:
    return f'<span class="badge {kind}">{html.escape(text)}</span>'


def render_dashboard(bundle: dict[str, Any]) -> str:
    triage = bundle["triage"]
    access = bundle["access_plan"]
    risk = bundle["risk_map"]
    care = bundle["care_plan"]
    timeline = bundle["timeline"]
    evidence_count = len(bundle["evidence_registry"])
    intervention_count = len(bundle["intervention_registry"])
    urgency_kind = "danger" if triage["urgency"] == "EMERGENCY_NOW" else "warning" if triage["urgency"] != "ROUTINE_OR_PLANNED" else "good"
    risk_rows = "".join(
        f"<tr><td>{html.escape(item['lane'].replace('_', ' ').title())}</td><td>{_badge(item['status'], 'warning' if 'ELEVATED' in item['status'] or 'SIGNAL' in item['status'] else 'neutral')}</td><td>{html.escape(item['why'])}</td></tr>"
        for item in risk["lanes"]
    )
    priorities = "".join(f"<li>{html.escape(item)}</li>" for item in care["priority_actions"])
    barriers = "".join(f"<li>{html.escape(item)}</li>" for item in access["barriers"]) or "<li>No access barrier was entered.</li>"
    eye_cards = []
    for eye_code, eye in timeline["eyes"].items():
        latest = eye.get("latest") or {}
        eye_cards.append(
            f"<article class='card'><h3>{eye_code.upper()}</h3>"
            f"<p><strong>Latest spherical equivalent:</strong> {html.escape(str(latest.get('spherical_equivalent_d')))}</p>"
            f"<p><strong>Latest axial length:</strong> {html.escape(str(latest.get('axial_length_mm')))}</p>"
            f"<p><strong>Annualized refraction change:</strong> {html.escape(str(eye.get('annualized_spherical_equivalent_change_d_per_year')))}</p>"
            f"<p><strong>Annualized axial change:</strong> {html.escape(str(eye.get('annualized_axial_length_change_mm_per_year')))}</p></article>"
        )
    embedded = json.dumps(bundle, ensure_ascii=True).replace("</", "<\\/")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DIKWP-MYOPIACOMMONS95</title>
<style>
:root {{ color-scheme: light dark; --bg:#f4f6f8; --panel:#ffffff; --text:#14202b; --muted:#52606d; --line:#d7dee5; --accent:#175cd3; --danger:#b42318; --warning:#b54708; --good:#027a48; }}
@media (prefers-color-scheme: dark) {{ :root {{ --bg:#0d1117; --panel:#161b22; --text:#f0f6fc; --muted:#9da7b3; --line:#30363d; --accent:#58a6ff; }} }}
* {{ box-sizing:border-box; }} body {{ margin:0; background:var(--bg); color:var(--text); font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif; line-height:1.5; }}
header {{ padding:2rem clamp(1rem,4vw,4rem); background:linear-gradient(135deg,#0b2e59,#175cd3); color:white; }} header h1 {{ margin:0 0 .35rem; font-size:clamp(1.8rem,4vw,3.4rem); }}
main {{ max-width:1200px; margin:auto; padding:1.25rem; }} .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:1rem; }}
.card, section {{ background:var(--panel); border:1px solid var(--line); border-radius:14px; padding:1rem; box-shadow:0 4px 18px rgba(0,0,0,.05); }} section {{ margin:1rem 0; }}
.metric {{ font-size:1.7rem; font-weight:750; }} .muted {{ color:var(--muted); }} .badge {{ display:inline-block; border-radius:999px; padding:.2rem .55rem; font-size:.78rem; font-weight:700; background:var(--line); }}
.badge.danger {{ background:#fee4e2; color:#912018; }} .badge.warning {{ background:#fef0c7; color:#93370d; }} .badge.good {{ background:#d1fadf; color:#05603a; }}
table {{ width:100%; border-collapse:collapse; }} th,td {{ padding:.65rem; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }}
.warning-box {{ border-left:5px solid var(--danger); }} code {{ overflow-wrap:anywhere; }} footer {{ padding:2rem; text-align:center; color:var(--muted); }}
</style>
</head>
<body>
<header><h1>DIKWP-MYOPIACOMMONS95</h1><p>Global patient-owned myopia recovery, progression management, high-myopia safety, access equity, and evidence accountability.</p></header>
<main>
<section class="warning-box"><h2>Safety first</h2><p>{_badge(triage['urgency'], urgency_kind)}</p><ul>{''.join(f'<li>{html.escape(item)}</li>' for item in triage['actions'])}</ul><p class="muted">This output is not a diagnosis and cannot rule out an emergency when data are missing.</p></section>
<div class="grid">
<article class="card"><div class="muted">Access tier</div><div class="metric">{html.escape(access['access_tier'])}</div></article>
<article class="card"><div class="muted">Life stage</div><div class="metric">{html.escape(risk['life_stage'])}</div></article>
<article class="card"><div class="muted">High-myopia risk context</div><div class="metric">{str(timeline['high_myopia_risk_context'])}</div></article>
<article class="card"><div class="muted">Evidence records</div><div class="metric">{evidence_count}</div><div class="muted">Intervention classes: {intervention_count}</div></article>
</div>
<section><h2>Priority actions</h2><ol>{priorities}</ol></section>
<section><h2>Per-eye timeline</h2><div class="grid">{''.join(eye_cards)}</div></section>
<section><h2>Seven care lanes</h2><div style="overflow-x:auto"><table><thead><tr><th>Lane</th><th>Status</th><th>Why it matters</th></tr></thead><tbody>{risk_rows}</tbody></table></div></section>
<section><h2>Access and equity</h2><ul>{barriers}</ul><ul>{''.join(f'<li>{html.escape(item)}</li>' for item in access['actions'])}</ul></section>
<section><h2>Non-negotiable claim boundaries</h2><ul><li>Correction is not structural reversal.</li><li>Progression control is not guaranteed arrest.</li><li>Refractive surgery does not erase high-myopia risk.</li><li>Not measured is not normal.</li><li>No product approval or indication is automatically global.</li></ul></section>
<section><h2>Patient ownership</h2><p>Exportable passport: <code>{html.escape(bundle['myopia_passport']['passport_id'])}</code></p><p>Compilation: <code>{html.escape(bundle['compile_id'])}</code></p></section>
</main>
<footer>Offline reference dashboard. No external scripts, tracking, diagnosis, prescription, payment, or device control.</footer>
<script type="application/json" id="myopia-data">{embedded}</script>
</body></html>"""
