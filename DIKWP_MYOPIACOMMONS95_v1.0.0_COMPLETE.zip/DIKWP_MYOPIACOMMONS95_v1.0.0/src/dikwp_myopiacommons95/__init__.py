"""DIKWP-MYOPIACOMMONS95 public package metadata."""

__version__ = "1.0.0"
SYSTEM_NAME = "DIKWP-MYOPIACOMMONS95"
SYSTEM_TITLE = "Global Myopia Recovery, Progression Management, High-Myopia Safety, Access Equity and Evidence Accountability OS"
DEFAULT_MODE = "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE"
EVIDENCE_SNAPSHOT = "2026-09-03"
