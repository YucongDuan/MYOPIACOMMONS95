from __future__ import annotations

from typing import Any


def mcp_manifest() -> dict[str, Any]:
    return {
        "protocol_profile": "MCP_READ_ONLY_REFERENCE_SUBSET",
        "specification_date": "2026-07-28",
        "certified_conformant": False,
        "tools": [
            {"name": "read_myopia_passport", "read_only": True, "description": "Read the patient-owned, selectively disclosed myopia passport."},
            {"name": "read_triage", "read_only": True, "description": "Read symptom-based urgency output without diagnosing."},
            {"name": "read_care_plan", "read_only": True, "description": "Read the evidence-bounded care and monitoring plan."},
            {"name": "audit_marketing_claim", "read_only": True, "description": "Screen a claim for predefined scientific, regulatory, and commercial-risk patterns."},
            {"name": "read_evidence_registry", "read_only": True, "description": "Read the dated evidence-source registry."},
        ],
        "write_tools": [],
        "external_action_authority": 0,
    }


def openapi_spec() -> dict[str, Any]:
    return {
        "openapi": "3.1.0",
        "info": {"title": "DIKWP-MYOPIACOMMONS95 Read-Only API", "version": "1.0.0"},
        "servers": [{"url": "http://127.0.0.1:8799"}],
        "paths": {
            "/health": {"get": {"responses": {"200": {"description": "Health status"}}}},
            "/bundle": {"get": {"responses": {"200": {"description": "Compiled local bundle"}}}},
            "/passport": {"get": {"responses": {"200": {"description": "Patient-owned myopia passport"}}}},
            "/triage": {"get": {"responses": {"200": {"description": "Safety triage output"}}}},
            "/care-plan": {"get": {"responses": {"200": {"description": "Care plan"}}}},
            "/evidence": {"get": {"responses": {"200": {"description": "Evidence registry"}}}},
        },
        "x-authority-boundaries": {
            "diagnosis": 0,
            "prescription": 0,
            "dose_selection": 0,
            "device_control": 0,
            "external_action": 0,
            "write_endpoints": 0,
        },
    }


def agent_instructions() -> list[str]:
    return [
        "Treat this system as decision support, not as a clinician, regulator, or emergency service.",
        "Read urgency before discussing long-term management.",
        "Never infer normality from a missing test or low-resource setting.",
        "Keep correction, progression control, functional recovery, structural disease, and permanent reversal separate.",
        "Do not transfer a product indication or approval across countries, models, concentrations, or populations.",
        "Preserve historical high-myopia risk after refractive surgery.",
        "Do not generate a drug concentration, prescription, device exposure, or surgical choice.",
        "Prefer patient-owned export, documented uncertainty, second opinions, and reversible decisions.",
    ]
