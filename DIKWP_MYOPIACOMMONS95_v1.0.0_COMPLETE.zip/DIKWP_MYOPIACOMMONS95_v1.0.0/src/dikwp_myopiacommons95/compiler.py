from __future__ import annotations

from pathlib import Path
from typing import Any

from . import DEFAULT_MODE, EVIDENCE_SNAPSHOT, SYSTEM_NAME, SYSTEM_TITLE, __version__
from .access import build_access_plan
from .care import build_care_plan
from .evidence import evidence_registry, intervention_registry, measurement_truth_contract
from .interop import agent_instructions, mcp_manifest, openapi_spec
from .jurisdiction import build_jurisdiction_policy
from .passport import build_myopia_passport
from .profile import validate_profile
from .research import structural_restoration_research_registry
from .render import render_clinical_handoff, render_dashboard, render_emergency_card, render_twelve_month_plan
from .risk import build_risk_map
from .timeline import analyze_timeline
from .triage import triage_profile
from .utils import public_file_hashes, read_json, sha256_obj, stable_id, timestamp_iso, write_json


def write_manifest(out_dir: str | Path, compile_id: str) -> dict[str, Any]:
    out = Path(out_dir)
    hashes = public_file_hashes(
        out,
        exclude={"MANIFEST.json", "outcome_ledger.jsonl", "adverse_event_ledger.jsonl", "consent_ledger.jsonl"},
    )
    manifest = {
        "system": SYSTEM_NAME,
        "version": __version__,
        "compile_id": compile_id,
        "file_count": len(hashes),
        "files": hashes,
    }
    write_json(out / "MANIFEST.json", manifest)
    return manifest


def compile_profile(profile_path: str | Path, out_dir: str | Path, source_date_epoch: str | None = None) -> dict[str, Any]:
    profile = read_json(profile_path)
    validate_profile(profile)
    triage = triage_profile(profile)
    timeline = analyze_timeline(profile)
    access_plan = build_access_plan(profile, triage)
    risk_map = build_risk_map(profile, timeline)
    care_plan = build_care_plan(profile, triage, timeline, risk_map, access_plan)
    passport = build_myopia_passport(profile, timeline, risk_map, care_plan)
    jurisdiction = build_jurisdiction_policy(profile)
    evidence = evidence_registry()
    interventions = intervention_registry()
    truth_contract = measurement_truth_contract()
    research_registry = structural_restoration_research_registry()
    deterministic = {
        "system": SYSTEM_NAME,
        "system_title": SYSTEM_TITLE,
        "version": __version__,
        "evidence_snapshot": EVIDENCE_SNAPSHOT,
        "mesh_mode": DEFAULT_MODE,
        "profile": profile,
        "triage": triage,
        "timeline": timeline,
        "access_plan": access_plan,
        "risk_map": risk_map,
        "care_plan": care_plan,
        "myopia_passport": passport,
        "jurisdiction_policy": jurisdiction,
        "evidence_registry": evidence,
        "intervention_registry": interventions,
        "measurement_truth_contract": truth_contract,
        "structural_restoration_research_registry": research_registry,
        "governance": {
            "factual_objectivity": True,
            "patient_protective_non_pseudoneutrality": True,
            "access_equity": True,
            "commercial_conflict_visibility": True,
            "patient_data_export": True,
            "automatic_diagnosis_authority": 0,
            "automatic_prescription_authority": 0,
            "automatic_dose_selection_authority": 0,
            "automatic_device_control_authority": 0,
            "automatic_surgical_selection_authority": 0,
            "automatic_external_action_authority": 0,
            "affiliate_product_ranking": False,
        },
        "claim_boundaries": {
            "permanent_axial_reversal_certificate": None,
            "binary_cure_certificate": None,
            "missing_test_equals_normal": False,
            "uncorrected_acuity_equals_recovery": False,
            "refractive_surgery_equals_cure": False,
            "regulatory_status_is_global": False,
            "output_is_medical_diagnosis": False,
        },
        "interop": {
            "mcp": mcp_manifest(),
            "openapi": openapi_spec(),
            "agent_instructions": agent_instructions(),
        },
    }
    content_digest = sha256_obj(deterministic)
    compile_id = stable_id("myopiacommons", {"content_digest": content_digest}, 28)
    bundle = {
        **deterministic,
        "compile_id": compile_id,
        "content_digest": content_digest,
        "generated_at": timestamp_iso(source_date_epoch),
    }
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "myopiacommons_bundle.json", bundle)
    write_json(out / "triage.json", triage)
    write_json(out / "timeline.json", timeline)
    write_json(out / "access_plan.json", access_plan)
    write_json(out / "risk_map.json", risk_map)
    write_json(out / "care_plan.json", care_plan)
    write_json(out / "myopia_passport.json", passport)
    write_json(out / "jurisdiction_policy.json", jurisdiction)
    write_json(out / "evidence_registry.json", evidence)
    write_json(out / "intervention_registry.json", interventions)
    write_json(out / "measurement_truth_contract.json", truth_contract)
    write_json(out / "structural_restoration_research_registry.json", research_registry)
    write_json(out / "mcp_tool_manifest.json", mcp_manifest())
    write_json(out / "openapi.json", openapi_spec())
    (out / "clinical_handoff.md").write_text(render_clinical_handoff(bundle), encoding="utf-8")
    (out / "home_emergency_card.md").write_text(render_emergency_card(bundle), encoding="utf-8")
    (out / "12_month_plan.md").write_text(render_twelve_month_plan(bundle), encoding="utf-8")
    (out / "dashboard.html").write_text(render_dashboard(bundle), encoding="utf-8")
    (out / "home_vision_log.csv").write_text(
        "date,eye,uncorrected_acuity,best_corrected_acuity,central_distortion,floaters_change,flashes,curtain_or_shadow,dryness_0_10,night_glare_0_10,reading_minutes,notes\n",
        encoding="utf-8",
    )
    for name in ("outcome_ledger.jsonl", "adverse_event_ledger.jsonl", "consent_ledger.jsonl"):
        (out / name).write_text("", encoding="utf-8")
    (out / "VERIFY.txt").write_text(
        "\n".join([
            SYSTEM_NAME,
            f"version={__version__}",
            f"compile_id={compile_id}",
            f"content_digest={content_digest}",
            "automatic_diagnosis_authority=0",
            "automatic_prescription_authority=0",
            "automatic_dose_selection_authority=0",
            "automatic_device_control_authority=0",
            "automatic_surgical_selection_authority=0",
            "permanent_axial_reversal_certificate=null",
            "global_regulatory_database_complete=false",
            "clinical_validation_complete=false",
            "",
        ]),
        encoding="utf-8",
    )
    manifest = write_manifest(out, compile_id)
    return {"bundle": bundle, "manifest": manifest, "out_dir": str(out)}
