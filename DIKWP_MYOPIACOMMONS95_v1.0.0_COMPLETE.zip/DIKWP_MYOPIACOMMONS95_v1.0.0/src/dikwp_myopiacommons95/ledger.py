from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .utils import canonical_json, sha256_bytes, timestamp_iso


def read_ledger(path: str | Path) -> list[dict[str, Any]]:
    source = Path(path)
    if not source.exists() or not source.read_text(encoding="utf-8").strip():
        return []
    return [json.loads(line) for line in source.read_text(encoding="utf-8").splitlines() if line.strip()]


def append_record(path: str | Path, payload: dict[str, Any], record_type: str, source_date_epoch: str | None = None) -> dict[str, Any]:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    records = read_ledger(destination)
    previous_hash = records[-1]["record_hash"] if records else "GENESIS"
    body = {
        "record_type": record_type,
        "recorded_at": timestamp_iso(source_date_epoch),
        "previous_hash": previous_hash,
        "payload": payload,
    }
    record_hash = sha256_bytes(canonical_json(body).encode("utf-8"))
    record = {**body, "record_hash": record_hash}
    with destination.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    return record


def verify_ledger(path: str | Path) -> dict[str, Any]:
    records = read_ledger(path)
    previous_hash = "GENESIS"
    failures: list[int] = []
    for index, record in enumerate(records):
        body = {key: record[key] for key in ("record_type", "recorded_at", "previous_hash", "payload")}
        expected = sha256_bytes(canonical_json(body).encode("utf-8"))
        if record.get("previous_hash") != previous_hash or record.get("record_hash") != expected:
            failures.append(index)
        previous_hash = record.get("record_hash", "")
    return {"valid": not failures, "record_count": len(records), "failure_indices": failures, "head_hash": previous_hash}
