from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .audit import audit_claims
from .compiler import compile_profile
from .utils import read_json, write_json


def demo_data_root() -> Path:
    packaged = Path(__file__).resolve().parent / "data" / "demo"
    if (packaged / "demo_index.json").exists():
        return packaged
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "examples"
        if (candidate / "demo_index.json").exists():
            return candidate
    raise FileNotFoundError("demo data could not be located")


def run_demo(out_dir: str | Path, source_date_epoch: str | None = "1788393600") -> dict[str, Any]:
    root = demo_data_root()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    index = read_json(root / "demo_index.json")
    results = []
    for item in index["cases"]:
        case_out = out / item["id"]
        result = compile_profile(root / item["profile"], case_out, source_date_epoch=source_date_epoch)
        results.append({
            "case_id": item["id"],
            "compile_id": result["bundle"]["compile_id"],
            "urgency": result["bundle"]["triage"]["urgency"],
            "access_tier": result["bundle"]["access_plan"]["access_tier"],
            "high_myopia_risk_context": result["bundle"]["timeline"]["high_myopia_risk_context"],
        })
    claims = read_json(root / "claims" / "claims.json")["claims"]
    audits = audit_claims(claims)
    write_json(out / "marketing_claim_audit.json", audits)
    summary = {
        "case_count": len(results),
        "cases": results,
        "claim_count": len(audits),
        "flagged_claim_count": sum(1 for item in audits if item["flagged"]),
        "all_examples_are_synthetic": True,
    }
    write_json(out / "demo_summary.json", summary)
    return summary
