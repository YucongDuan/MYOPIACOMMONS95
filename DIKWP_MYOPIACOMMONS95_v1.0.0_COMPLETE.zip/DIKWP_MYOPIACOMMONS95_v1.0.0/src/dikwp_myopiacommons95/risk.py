from __future__ import annotations

from typing import Any

from .profile import life_stage


def build_risk_map(profile: dict[str, Any], timeline: dict[str, Any]) -> dict[str, Any]:
    age = float(profile["age_years"])
    history = profile.get("history", {}) or {}
    symptoms = profile.get("symptoms", {}) or {}
    stage = life_stage(age)
    progression_signal = False
    for eye in timeline["eyes"].values():
        se_change = eye.get("annualized_spherical_equivalent_change_d_per_year")
        al_change = eye.get("annualized_axial_length_change_mm_per_year")
        if isinstance(se_change, (int, float)) and se_change <= -0.25:
            progression_signal = True
        if isinstance(al_change, (int, float)) and al_change >= 0.10:
            progression_signal = True
    lanes = [
        {
            "lane": "REFRACTION_AND_DAILY_FUNCTION",
            "status": "NEEDS_BASELINE" if not profile.get("measurements") else "TRACKED",
            "why": "Clear vision, near tasks, education, work, mobility, and quality of life require accurate correction and task-specific assessment.",
        },
        {
            "lane": "CHILD_OR_ADULT_PROGRESSION",
            "status": "PROGRESSION_SIGNAL" if progression_signal else ("MONITOR" if stage in {"SCHOOL_AGE_CHILD", "ADOLESCENT", "YOUNG_ADULT"} else "AGE_AND_HISTORY_DEPENDENT"),
            "why": "Myopia can progress in childhood and may continue or begin in adulthood; interpretation depends on age, measurement quality, and interval.",
        },
        {
            "lane": "HIGH_MYOPIA_RETINA_AND_MACULA",
            "status": "ELEVATED_CONTEXT" if timeline["high_myopia_risk_context"] or history.get("pathologic_myopia") else "STANDARD_CONTEXT",
            "why": "High refractive error or long axial length increases the need to preserve retinal and macular surveillance, even after refractive surgery.",
        },
        {
            "lane": "GLAUCOMA_AND_OPTIC_NERVE",
            "status": "ELEVATED_CONTEXT" if history.get("glaucoma_suspect_or_diagnosis") or history.get("family_history_glaucoma") else "STANDARD_CONTEXT",
            "why": "Optic-nerve assessment may require longitudinal multimodal interpretation, especially in highly myopic eyes.",
        },
        {
            "lane": "LENS_PRESBYOPIA_AND_NIGHT_VISION",
            "status": "ACTIVE_REVIEW" if age >= 40 or symptoms.get("new_night_driving_difficulty") else "AGE_DEPENDENT",
            "why": "Presbyopia, cataract, aberrations, ocular surface disease, retina, and correction can all affect midlife or night vision.",
        },
        {
            "lane": "OCULAR_SURFACE_AND_CONTACT_LENS_SAFETY",
            "status": "ACTIVE_REVIEW" if history.get("contact_lens_wear") or symptoms.get("fluctuating_blur") or symptoms.get("dryness") else "STANDARD_CONTEXT",
            "why": "Tear-film instability and contact-lens complications can cause fluctuating blur and, occasionally, urgent corneal risk.",
        },
        {
            "lane": "ACCESS_COST_AND_COMMERCIAL_BURDEN",
            "status": "ACTIVE_REVIEW" if any((profile.get("access", {}) or {}).values()) else "REVIEW",
            "why": "A clinically effective plan can still fail if it is unaffordable, inaccessible, opaque, or dependent on one vendor.",
        },
    ]
    return {
        "life_stage": stage,
        "progression_signal": progression_signal,
        "high_myopia_risk_context": timeline["high_myopia_risk_context"],
        "lanes": lanes,
        "not_a_diagnosis": True,
    }
