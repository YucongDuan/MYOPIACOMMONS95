from __future__ import annotations

from typing import Any

from .profile import life_stage


def _latest_present(timeline: dict[str, Any], field: str) -> bool:
    for eye in timeline.get("eyes", {}).values():
        latest = eye.get("latest") or {}
        if latest.get(field) is not None:
            return True
    return False


def build_care_plan(
    profile: dict[str, Any],
    triage: dict[str, Any],
    timeline: dict[str, Any],
    risk_map: dict[str, Any],
    access_plan: dict[str, Any],
) -> dict[str, Any]:
    age = float(profile["age_years"])
    stage = life_stage(age)
    history = profile.get("history", {}) or {}
    symptoms = profile.get("symptoms", {}) or {}
    goals = profile.get("goals", []) or []

    if triage["urgency"] in {"EMERGENCY_NOW", "URGENT_SAME_DAY"}:
        priority_actions = triage["actions"] + [
            "Carry or export prior refraction, axial-length, retinal, surgical, medication, allergy, and contact-lens records when available.",
            "After urgent disease has been addressed, return to the full lifelong myopia pathway rather than treating the emergency as the entire care plan.",
        ]
    else:
        priority_actions = [
            "Establish a qualified, person-centred baseline for each eye rather than treating the two eyes as one average.",
            "Separate correction, functional recovery, progression management, structural disease, and access burden into different outcomes.",
            "Agree in writing on what will be measured, when it will be remeasured, and what would trigger continuation, change, referral, or stopping.",
        ]
        if triage["urgency"] == "EXPEDITED_WITHIN_1_TO_2_WEEKS":
            priority_actions.insert(0, "Arrange the accelerated eye examination described in the triage output.")

    baseline: list[dict[str, Any]] = [
        {"item": "Monocular uncorrected and best-corrected visual acuity", "purpose": "Separate optical blur from unexplained loss of best-corrected function."},
        {"item": "Current refraction with method documented", "purpose": "Provide usable correction and a comparable baseline."},
        {"item": "Ocular-health examination", "purpose": "Avoid treating every blur as uncomplicated refractive error."},
        {"item": "Real-world visual-function goals", "purpose": "Measure reading, education, work, mobility, night driving, comfort, and participation."},
        {"item": "Cost, travel, time, adherence, and adverse-event burden", "purpose": "Prevent a theoretically effective plan from failing in the patient's actual life."},
    ]
    if age < 18:
        baseline.extend([
            {"item": "Cycloplegic refraction when clinically appropriate", "purpose": "Reduce accommodation-related misclassification."},
            {"item": "Axial length on a documented instrument when available", "purpose": "Track ocular growth rather than relying on refraction alone."},
            {"item": "Family, onset-age, outdoor, near-work, and prior-progression history", "purpose": "Support risk stratification and shared decision-making."},
        ])
    elif stage == "YOUNG_ADULT":
        baseline.extend([
            {"item": "Serial refraction and axial length when progression is suspected", "purpose": "Adult onset or progression is possible and should not be dismissed solely because schooling ended."},
            {"item": "Occupational and near-task exposure", "purpose": "Align correction and monitoring with current demands."},
        ])
    if timeline["high_myopia_risk_context"] or history.get("pathologic_myopia") or history.get("historical_high_myopia_before_surgery"):
        baseline.extend([
            {"item": "Dilated peripheral retinal examination", "purpose": "Assess tears, holes, lattice, detachment, and other peripheral findings in clinical context."},
            {"item": "Macular assessment and OCT when indicated", "purpose": "Assess myopic macular degeneration, neovascular, tractional, or other macular pathology."},
            {"item": "Optic-nerve and glaucoma assessment", "purpose": "Interpret pressure, disc appearance, OCT, fields, and longitudinal change without relying on one color code."},
            {"item": "Preserve pre-surgery refraction and axial length", "purpose": "Do not erase structural risk after LASIK, SMILE, ICL, or lens surgery."},
        ])
    if symptoms.get("dryness") or symptoms.get("fluctuating_blur") or history.get("contact_lens_wear"):
        baseline.append({"item": "Ocular-surface, tear-film, lid, and contact-lens assessment", "purpose": "Treat reversible instability and detect corneal risk."})
    if age >= 40:
        baseline.append({"item": "Lens, presbyopia, contrast, glare, and task-distance assessment", "purpose": "Separate cataract, presbyopia, ocular surface, retinal, optic-nerve, and correction contributions."})

    progression_options = [
        {
            "class": "Myopia-control spectacle lenses",
            "consider_when": "A child or adolescent has clinically meaningful progression and a product appropriate to the local jurisdiction is available.",
            "must_measure": ["cycloplegic refraction", "axial length when available", "visual function", "adverse effects", "adherence", "total cost"],
            "boundary": "A result for one lens design cannot be transferred to every lens marketed as defocus or myopia control.",
        },
        {
            "class": "Myopia-control soft contact lenses",
            "consider_when": "The patient is eligible, can follow hygiene and replacement requirements, and the exact product and indication are verified.",
            "must_measure": ["corneal safety", "wear and replacement adherence", "refraction", "axial length", "symptoms", "cost"],
            "boundary": "Contact-lens infection risk and product-specific scope must be disclosed.",
        },
        {
            "class": "Orthokeratology",
            "consider_when": "A qualified fitter can provide topography, hygiene governance, emergency access, and longitudinal monitoring.",
            "must_measure": ["axial length", "corneal health", "topography", "wear adherence", "adverse events", "rebound or resumption after stopping"],
            "boundary": "Daytime unaided clarity reflects corneal reshaping and is not proof of permanent axial reversal.",
        },
        {
            "class": "Low-concentration atropine",
            "consider_when": "A qualified clinician judges the formulation, concentration, age, progression pattern, legal status, and monitoring plan appropriate.",
            "must_measure": ["cycloplegic refraction", "axial length", "pupil and near symptoms", "adherence", "side effects", "response after stopping"],
            "boundary": "The platform does not prescribe a concentration; trials show population and formulation heterogeneity.",
        },
        {
            "class": "Repeated low-level red-light therapy",
            "consider_when": "Only in research or a tightly governed specialist pathway with exact device verification, dosimetry, retinal monitoring, and informed discussion of uncertainty.",
            "must_measure": ["exact device and exposure", "retinal imaging and function", "axial length", "adverse effects", "rebound", "regulatory status"],
            "boundary": "Do not market as globally established, permanently restorative, or proven safe for every device and population.",
        },
    ]

    phases = [
        {
            "phase": "0_TO_14_DAYS",
            "objectives": [
                "Complete urgent triage and secure basic correction or referral.",
                "Collect prior records and establish per-eye baseline data.",
                "Identify unavailable measurements and access barriers without labeling them normal.",
            ],
        },
        {
            "phase": "15_TO_45_DAYS",
            "objectives": [
                "Restore correctable clarity, ocular-surface stability, task-specific near or distance function, and safe contact-lens use.",
                "For progressing children or adolescents, compare evidence-based options with product and jurisdiction checks.",
                "For high myopia or unexplained reduced best-corrected vision, complete retinal, macular, and optic-nerve pathways.",
            ],
        },
        {
            "phase": "46_TO_90_DAYS",
            "objectives": [
                "Confirm that the plan is usable, affordable, and acceptable in daily life.",
                "Record side effects, adherence, vendor claims, and conflicts of interest.",
                "Set the first outcome review and prewrite continuation, change, referral, and stopping criteria.",
            ],
        },
        {
            "phase": "3_TO_12_MONTHS",
            "objectives": [
                "Repeat age- and risk-appropriate outcomes under comparable conditions.",
                "Evaluate absolute change, uncertainty, adverse events, function, and burden rather than one promotional percentage.",
                "Update the patient-owned passport and export records before changing clinic, product, country, or care team.",
            ],
        },
        {
            "phase": "LIFELONG",
            "objectives": [
                "Continue retinal, macular, optic-nerve, lens, ocular-surface, and functional surveillance according to personal risk.",
                "Retain high-myopia history after refractive surgery or apparent prescription normalization.",
                "Use vision rehabilitation promptly when function remains limited while continuing disease-directed care where appropriate.",
            ],
        },
    ]

    recovery_vector = {
        "optical_clarity": {"recoverable": True, "success_measure": "task-specific corrected visual performance"},
        "accommodative_or_binocular_function": {"recoverable_when_diagnosed": True, "success_measure": "disorder-specific functional endpoint"},
        "ocular_surface_stability": {"recoverable_when_treatable": True, "success_measure": "symptom and fluctuation improvement with examination findings"},
        "myopia_progression": {"manageable": True, "guaranteed_arrest": False, "success_measure": "serial cycloplegic refraction and axial length where appropriate"},
        "established_axial_structure": {"routine_permanent_reversal_proven": False, "success_measure": "would require durable objective structural evidence and independent replication"},
        "complication_risk": {"reducible_or_manageable": True, "risk_elimination_promised": False, "success_measure": "timely detection, disease-specific care, and preserved function"},
        "daily_function_and_participation": {"rehabilitation_available": True, "success_measure": "patient-prioritized education, work, mobility, reading, and independence outcomes"},
        "access_and_financial_burden": {"modifiable": True, "success_measure": "safe care obtained without hidden or unsustainable burden"},
    }

    portable_record_checklist = [
        "Current and historical prescriptions for each eye, with cycloplegia status",
        "Axial-length values with date, device, and eye",
        "Best-corrected acuity and unexplained acuity loss",
        "Retinal and macular examination reports, photographs, and OCT",
        "Optic-nerve photographs, OCT, visual fields, pressure, and corneal-thickness context",
        "Corneal topography, contact-lens fit, and adverse-event history",
        "Prior LASIK, PRK, SMILE, ICL, cataract, retinal laser, injection, or surgery records",
        "Exact treatment product, formulation, concentration, device, start and stop dates",
        "Adverse effects, adherence, total cost, travel, time burden, and patient-reported function",
        "Written consent, conflicts of interest, alternatives, and stopping rules",
    ]

    return {
        "life_stage": stage,
        "goals_reported": goals,
        "priority_actions": priority_actions,
        "baseline_assessment": baseline,
        "progression_management_options_for_clinician_discussion": progression_options if age < 25 else [],
        "access_actions": access_plan["actions"],
        "recovery_vector": recovery_vector,
        "time_phases": phases,
        "portable_record_checklist": portable_record_checklist,
        "review_contract": {
            "define_outcomes_before_starting": True,
            "record_absolute_change": True,
            "record_measurement_uncertainty": True,
            "record_adverse_events_and_dropouts": True,
            "record_cost_and_time_burden": True,
            "prewrite_stopping_rules": True,
            "allow_second_opinion_and_data_export": True,
        },
        "clinical_authority": {
            "automatic_diagnosis": False,
            "automatic_prescription": False,
            "automatic_dose_selection": False,
            "automatic_device_control": False,
            "qualified_human_clinician_required": True,
        },
    }
