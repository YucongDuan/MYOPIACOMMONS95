from __future__ import annotations

from typing import Any


def _present(source: dict[str, Any], *keys: str) -> bool:
    return any(bool(source.get(key)) for key in keys)


def triage_profile(profile: dict[str, Any]) -> dict[str, Any]:
    symptoms = profile.get("symptoms", {}) or {}
    history = profile.get("history", {}) or {}
    reasons: list[str] = []
    urgency = "ROUTINE_OR_PLANNED"

    emergency_rules = [
        (symptoms.get("sudden_vision_loss"), "Sudden or rapidly worsening loss of vision"),
        (symptoms.get("curtain_or_shadow"), "A curtain, fixed shadow, or new field defect"),
        (symptoms.get("chemical_exposure"), "Chemical exposure to the eye"),
        (symptoms.get("penetrating_or_high_speed_trauma"), "Penetrating or high-speed eye trauma"),
    ]
    for present, reason in emergency_rules:
        if present:
            urgency = "EMERGENCY_NOW"
            reasons.append(reason)
    if _present(symptoms, "sudden_new_floaters", "new_flashes"):
        urgency = "EMERGENCY_NOW"
        reasons.append("A sudden increase in floaters or new flashes can accompany a retinal tear or detachment")

    same_day: list[str] = []
    if _present(symptoms, "new_metamorphopsia", "new_central_scotoma", "rapid_monocular_central_blur"):
        same_day.append("New distortion, a central blind spot, or rapid one-eye central blur requires urgent macular assessment")
    if history.get("contact_lens_wear") and _present(symptoms, "eye_pain", "red_eye", "photophobia", "discharge", "sudden_blur"):
        same_day.append("Pain, redness, light sensitivity, discharge, or sudden blur during contact-lens wear requires urgent corneal assessment")
    if symptoms.get("severe_eye_pain") or (symptoms.get("red_eye") and symptoms.get("photophobia")):
        same_day.append("Severe eye pain or a red light-sensitive eye requires same-day assessment")
    if same_day and urgency != "EMERGENCY_NOW":
        urgency = "URGENT_SAME_DAY"
        reasons.extend(same_day)

    expedited: list[str] = []
    if _present(symptoms, "gradual_monocular_decline", "persistent_distortion", "new_night_driving_difficulty", "frequent_refraction_change"):
        expedited.append("Persistent one-eye decline, distortion, new night-driving difficulty, or frequent prescription change merits an accelerated examination")
    if history.get("glaucoma_suspect_or_diagnosis") and _present(symptoms, "suspected_field_loss", "worsening_side_vision"):
        expedited.append("Possible field loss in a person with glaucoma risk requires accelerated review")
    if expedited and urgency == "ROUTINE_OR_PLANNED":
        urgency = "EXPEDITED_WITHIN_1_TO_2_WEEKS"
        reasons.extend(expedited)

    actions = {
        "EMERGENCY_NOW": [
            "Seek an eye doctor or emergency department immediately.",
            "Do not drive yourself. Stop contact-lens wear and do not delay care for exercises, massage, red-light exposure, or online advice.",
            "For chemical exposure, begin continuous clean-water irrigation immediately while obtaining emergency help.",
        ],
        "URGENT_SAME_DAY": [
            "Arrange same-day qualified eye care, choosing retinal, macular, or corneal emergency capability as relevant.",
            "Stop contact-lens wear when infection is possible and do not start steroid eye drops without examination.",
        ],
        "EXPEDITED_WITHIN_1_TO_2_WEEKS": [
            "Arrange a comprehensive examination within one to two weeks; escalate sooner if symptoms become sudden or more severe.",
            "Record which eye is affected and whether straight lines, central detail, night vision, or side vision changed.",
        ],
        "ROUTINE_OR_PLANNED": [
            "No entered field triggered an emergency rule, but missing or inaccurate data cannot rule out disease.",
            "Continue the age- and risk-appropriate examination and monitoring pathway.",
        ],
    }[urgency]
    return {
        "urgency": urgency,
        "reasons": reasons,
        "actions": actions,
        "not_a_diagnosis": True,
        "missing_or_false_fields_do_not_rule_out_emergency": True,
    }
