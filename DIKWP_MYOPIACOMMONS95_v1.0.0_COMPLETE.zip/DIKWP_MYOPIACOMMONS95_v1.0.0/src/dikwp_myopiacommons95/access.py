from __future__ import annotations

from typing import Any

SPECS_PILLARS = ["SERVICES", "PERSONNEL", "EDUCATION", "COST", "SURVEILLANCE"]


def build_access_plan(profile: dict[str, Any], triage: dict[str, Any]) -> dict[str, Any]:
    access = profile.get("access", {}) or {}
    barriers: list[str] = []
    actions: list[str] = []
    if access.get("affordability_barrier"):
        barriers.append("AFFORDABILITY")
        actions.append("Request a written minimum-safe-care option, total expected cost, lower-cost alternatives, and eligibility for public, charitable, school, or employer-supported services.")
    if access.get("provider_distance_minutes", 0) and access.get("provider_distance_minutes", 0) > 90:
        barriers.append("DISTANCE")
        actions.append("Create a travel-ready referral packet and identify the nearest facility able to perform the missing high-value examination in one visit.")
    if not access.get("cycloplegic_refraction_available", True) and profile.get("age_years", 100) < 18:
        barriers.append("CYCLOPLEGIC_REFRACTION_UNAVAILABLE")
        actions.append("Do not label a child as structurally recovered or progressing from non-cycloplegic refraction alone; seek a referral pathway for cycloplegic assessment when clinically appropriate.")
    if not access.get("axial_length_available", True):
        barriers.append("AXIAL_LENGTH_UNAVAILABLE")
        actions.append("Use serial cycloplegic refraction and documented examination findings while recording that axial progression cannot be directly measured; avoid fabricated axial estimates.")
    if not access.get("dilated_retinal_exam_available", True):
        barriers.append("DILATED_RETINAL_EXAM_UNAVAILABLE")
        actions.append("For high-myopia context, new symptoms, or reduced best-corrected vision, prioritize referral to a site that can examine the peripheral retina and macula.")
    if not access.get("retinal_specialist_available", True):
        barriers.append("RETINAL_SPECIALIST_UNAVAILABLE")
        actions.append("Establish an escalation route through a general eye professional, tele-ophthalmology where lawful and clinically suitable, or a regional referral center; remote review does not replace urgent in-person examination when detachment is possible.")
    if not access.get("reliable_internet", True):
        barriers.append("DIGITAL_ACCESS")
        actions.append("Use printable and offline records; do not make cloud access a condition for receiving the patient-owned passport.")
    if not access.get("safe_spectacles_available", True):
        barriers.append("BASIC_CORRECTION_UNAVAILABLE")
        actions.append("Prioritize accurate, durable, affordable spectacles and a usable near-vision solution before selling premium add-ons.")
    if triage["urgency"] == "EMERGENCY_NOW":
        tier = "A0_EMERGENCY_ACCESS"
    elif "BASIC_CORRECTION_UNAVAILABLE" in barriers:
        tier = "A1_BASIC_REFRACTIVE_ACCESS"
    elif any(item in barriers for item in {"DILATED_RETINAL_EXAM_UNAVAILABLE", "RETINAL_SPECIALIST_UNAVAILABLE"}):
        tier = "A2_DIAGNOSTIC_REFERRAL_GAP"
    elif any(item in barriers for item in {"AXIAL_LENGTH_UNAVAILABLE", "CYCLOPLEGIC_REFRACTION_UNAVAILABLE"}):
        tier = "A3_MONITORING_GAP"
    else:
        tier = "A4_COMPREHENSIVE_PATHWAY_AVAILABLE"
    return {
        "access_tier": tier,
        "barriers": barriers,
        "actions": actions or ["Preserve an affordable baseline pathway and disclose optional versus necessary services."],
        "specs_2030_alignment": {pillar: True for pillar in SPECS_PILLARS},
        "equity_rules": [
            "Basic correction, urgent triage, and referral information must not be paywalled.",
            "Unavailable tests must be recorded as missing, not imputed as normal.",
            "A premium product is not a substitute for a complete safety examination.",
            "The patient can export the record without vendor lock-in.",
        ],
    }
