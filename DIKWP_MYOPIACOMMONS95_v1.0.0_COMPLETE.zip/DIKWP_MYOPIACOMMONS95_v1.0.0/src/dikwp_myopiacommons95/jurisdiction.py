from __future__ import annotations

from typing import Any

KNOWN_REGULATORY_PORTALS = {
    "US": "https://www.fda.gov/medical-devices",
    "USA": "https://www.fda.gov/medical-devices",
    "GB": "https://www.gov.uk/government/organisations/medicines-and-healthcare-products-regulatory-agency",
    "UK": "https://www.gov.uk/government/organisations/medicines-and-healthcare-products-regulatory-agency",
    "AU": "https://www.tga.gov.au/",
    "AUS": "https://www.tga.gov.au/",
    "CA": "https://www.canada.ca/en/health-canada/services/drugs-health-products/medical-devices.html",
    "CAN": "https://www.canada.ca/en/health-canada/services/drugs-health-products/medical-devices.html",
    "SG": "https://www.hsa.gov.sg/medical-devices",
    "SGP": "https://www.hsa.gov.sg/medical-devices",
    "CN": "https://www.nmpa.gov.cn/",
    "CHN": "https://www.nmpa.gov.cn/",
    "JP": "https://www.pmda.go.jp/english/",
    "JPN": "https://www.pmda.go.jp/english/",
    "IN": "https://cdsco.gov.in/",
    "IND": "https://cdsco.gov.in/",
    "EU": "https://health.ec.europa.eu/medical-devices-sector_en",
    "EEA": "https://health.ec.europa.eu/medical-devices-sector_en",
}


def build_jurisdiction_policy(profile: dict[str, Any]) -> dict[str, Any]:
    code = profile.get("country_code", "").upper()
    portal = KNOWN_REGULATORY_PORTALS.get(code)
    return {
        "country_code": code,
        "regulatory_portal": portal,
        "verification_status": "LOCAL_PRODUCT_AND_INDICATION_VERIFICATION_REQUIRED",
        "rules": [
            "Never transfer an approval, indication, age range, clinical result, or safety statement from one country or product to another without verification.",
            "A CE mark or market listing does not by itself establish equivalent myopia-control efficacy for every product.",
            "Verify the exact product name, model, formulation, concentration, intended population, prescriber requirements, and post-market warnings.",
            "Record off-label use explicitly and require a qualified clinician to explain alternatives, uncertainty, monitoring, and stopping rules.",
            "The registry in this reference implementation is not a complete or continuously synchronized global regulatory database.",
        ],
        "known_examples_are_not_global_endorsements": [
            "US FDA records exist for specific products such as MiSight 1 Day and, from 2025, specific Stellest spectacle lenses; their indications must not be generalized to other products or countries.",
        ],
    }
