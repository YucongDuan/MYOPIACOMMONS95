from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .utils import read_json


def _load_outputs(output_dir: str | Path) -> dict[str, Any]:
    root = Path(output_dir)
    mapping = {
        "/bundle": "myopiacommons_bundle.json",
        "/passport": "myopia_passport.json",
        "/triage": "triage.json",
        "/care-plan": "care_plan.json",
        "/evidence": "evidence_registry.json",
    }
    loaded: dict[str, Any] = {}
    for route, filename in mapping.items():
        path = root / filename
        if path.exists():
            loaded[route] = read_json(path)
    return loaded


def make_handler(output_dir: str | Path):
    data = _load_outputs(output_dir)

    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, body: Any) -> None:
            payload = json.dumps(body, ensure_ascii=False, indent=2).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/health":
                self._send(200, {"status": "ok", "read_only": True})
            elif self.path in data:
                self._send(200, data[self.path])
            else:
                self._send(404, {"error": "not_found"})

        def do_POST(self) -> None:  # noqa: N802
            self._send(405, {"error": "write_operations_disabled"})

        def do_PUT(self) -> None:  # noqa: N802
            self._send(405, {"error": "write_operations_disabled"})

        def do_DELETE(self) -> None:  # noqa: N802
            self._send(405, {"error": "write_operations_disabled"})

        def log_message(self, format: str, *args: Any) -> None:
            return

    return Handler


def serve(output_dir: str | Path, host: str = "127.0.0.1", port: int = 8799) -> None:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("The reference server may bind only to a loopback address")
    server = ThreadingHTTPServer((host, port), make_handler(output_dir))
    try:
        server.serve_forever()
    finally:
        server.server_close()
