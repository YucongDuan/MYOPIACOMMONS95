from __future__ import annotations

from datetime import date
from typing import Any

from .utils import bounded_number

ALLOWED_SHARE_LEVELS = {"PRIVATE_LOCAL", "CLINICIAN_HANDOFF", "RESEARCH_DEIDENTIFIED", "DEMO_SYNTHETIC"}


def validate_profile(profile: dict[str, Any]) -> None:
    if not isinstance(profile, dict):
        raise ValueError("profile must be a JSON object")
    if not isinstance(profile.get("patient_id"), str) or not profile["patient_id"].strip():
        raise ValueError("patient_id is required")
    age = profile.get("age_years")
    if not isinstance(age, (int, float)) or age < 0 or age > 125:
        raise ValueError("age_years must be between 0 and 125")
    country = profile.get("country_code")
    if not isinstance(country, str) or len(country.strip()) not in {2, 3}:
        raise ValueError("country_code must be a two- or three-character code")
    consent = profile.get("consent", {}) or {}
    if consent.get("use_for_local_decision_support") is not True:
        raise ValueError("explicit local decision-support consent is required")
    if consent.get("share_level", "PRIVATE_LOCAL") not in ALLOWED_SHARE_LEVELS:
        raise ValueError(f"share_level must be one of {sorted(ALLOWED_SHARE_LEVELS)}")
    measurements = profile.get("measurements", []) or []
    if not isinstance(measurements, list):
        raise ValueError("measurements must be a list")
    for index, measurement in enumerate(measurements):
        if not isinstance(measurement, dict):
            raise ValueError(f"measurement {index} must be an object")
        raw_date = measurement.get("date")
        if not isinstance(raw_date, str):
            raise ValueError(f"measurement {index} requires an ISO date")
        try:
            date.fromisoformat(raw_date)
        except ValueError as exc:
            raise ValueError(f"measurement {index} has an invalid ISO date") from exc
        eyes = measurement.get("eyes", {}) or {}
        if not isinstance(eyes, dict):
            raise ValueError(f"measurement {index}.eyes must be an object")
        for eye in ("od", "os"):
            eye_data = eyes.get(eye, {}) or {}
            if not isinstance(eye_data, dict):
                raise ValueError(f"measurement {index}.{eye} must be an object")
            sphere = eye_data.get("sphere_d")
            cylinder = eye_data.get("cylinder_d")
            axial = eye_data.get("axial_length_mm")
            if sphere is not None and bounded_number(sphere, -40, 20) is None:
                raise ValueError(f"measurement {index}.{eye}.sphere_d is outside a plausible data-entry range")
            if cylinder is not None and bounded_number(cylinder, -15, 15) is None:
                raise ValueError(f"measurement {index}.{eye}.cylinder_d is outside a plausible data-entry range")
            if axial is not None and bounded_number(axial, 15, 40) is None:
                raise ValueError(f"measurement {index}.{eye}.axial_length_mm is outside a plausible data-entry range")


def life_stage(age_years: float) -> str:
    if age_years < 6:
        return "EARLY_CHILDHOOD"
    if age_years < 13:
        return "SCHOOL_AGE_CHILD"
    if age_years < 18:
        return "ADOLESCENT"
    if age_years < 41:
        return "YOUNG_ADULT"
    if age_years < 66:
        return "MIDDLE_AGE"
    return "OLDER_ADULT"
