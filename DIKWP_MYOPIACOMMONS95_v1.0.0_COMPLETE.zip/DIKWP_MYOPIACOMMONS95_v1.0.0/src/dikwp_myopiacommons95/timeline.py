from __future__ import annotations

from datetime import date
from typing import Any


def spherical_equivalent(eye: dict[str, Any]) -> float | None:
    sphere = eye.get("sphere_d")
    cylinder = eye.get("cylinder_d", 0.0)
    if not isinstance(sphere, (int, float)) or not isinstance(cylinder, (int, float)):
        return None
    return round(float(sphere) + float(cylinder) / 2.0, 3)


def _annualized_change(first_value: float, last_value: float, days: int) -> float | None:
    if days < 90:
        return None
    return round((last_value - first_value) * 365.25 / days, 4)


def analyze_timeline(profile: dict[str, Any]) -> dict[str, Any]:
    ordered = sorted(profile.get("measurements", []) or [], key=lambda item: item["date"])
    eyes: dict[str, Any] = {}
    high_context = bool(profile.get("history", {}).get("declared_high_myopia"))
    for eye_code in ("od", "os"):
        points: list[dict[str, Any]] = []
        for measurement in ordered:
            eye = (measurement.get("eyes", {}) or {}).get(eye_code, {}) or {}
            se = spherical_equivalent(eye)
            axial = eye.get("axial_length_mm") if isinstance(eye.get("axial_length_mm"), (int, float)) else None
            if se is None and axial is None:
                continue
            points.append({
                "date": measurement["date"],
                "cycloplegic": bool(measurement.get("cycloplegic")),
                "device_id": measurement.get("device_id"),
                "spherical_equivalent_d": se,
                "axial_length_mm": float(axial) if axial is not None else None,
                "best_corrected_acuity_logmar": eye.get("best_corrected_acuity_logmar"),
            })
            if se is not None and se <= -6.0:
                high_context = True
            if axial is not None and float(axial) >= 26.5:
                high_context = True
        annual_se = None
        annual_axial = None
        comparable_axial = False
        if len(points) >= 2:
            first, last = points[0], points[-1]
            days = (date.fromisoformat(last["date"]) - date.fromisoformat(first["date"])).days
            if first["spherical_equivalent_d"] is not None and last["spherical_equivalent_d"] is not None:
                annual_se = _annualized_change(first["spherical_equivalent_d"], last["spherical_equivalent_d"], days)
            same_device = first.get("device_id") and first.get("device_id") == last.get("device_id")
            if first["axial_length_mm"] is not None and last["axial_length_mm"] is not None and same_device:
                comparable_axial = True
                annual_axial = _annualized_change(first["axial_length_mm"], last["axial_length_mm"], days)
        eyes[eye_code] = {
            "points": points,
            "annualized_spherical_equivalent_change_d_per_year": annual_se,
            "annualized_axial_length_change_mm_per_year": annual_axial,
            "axial_comparison_same_device": comparable_axial,
            "latest": points[-1] if points else None,
        }
    return {
        "eyes": eyes,
        "high_myopia_risk_context": high_context,
        "measurement_interpretation": [
            "Cycloplegic refraction is especially important in children and when accommodation may distort refraction.",
            "Axial-length trends should preferably use the same instrument and comparable measurement conditions.",
            "A change in uncorrected visual acuity alone does not establish axial shortening or structural recovery.",
        ],
    }
