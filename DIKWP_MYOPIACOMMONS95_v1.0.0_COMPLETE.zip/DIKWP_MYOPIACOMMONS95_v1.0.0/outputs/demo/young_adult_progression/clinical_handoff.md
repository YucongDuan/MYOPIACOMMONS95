# DIKWP-MYOPIACOMMONS95 Clinical Handoff

> Decision support only. This document is not a diagnosis, prescription, regulatory determination, or emergency service.

- Patient identifier: `demo-young-adult-001`
- Age: 24
- Country code: IN
- Preferred language: English
- Urgency: **EXPEDITED_WITHIN_1_TO_2_WEEKS**
- High-myopia risk context: **False**

## Urgency reasons
- Persistent one-eye decline, distortion, new night-driving difficulty, or frequent prescription change merits an accelerated examination

## Priority actions
- Arrange the accelerated eye examination described in the triage output.
- Establish a qualified, person-centred baseline for each eye rather than treating the two eyes as one average.
- Separate correction, functional recovery, progression management, structural disease, and access burden into different outcomes.
- Agree in writing on what will be measured, when it will be remeasured, and what would trigger continuation, change, referral, or stopping.

## Latest per-eye data
### OD
- date: 2026-08-10
- cycloplegic: False
- device_id: BIO-B
- spherical_equivalent_d: -4.875
- axial_length_mm: 25.63
- best_corrected_acuity_logmar: 0.0
- Annualized spherical-equivalent change: -0.3345
- Annualized axial-length change: 0.1405
### OS
- date: 2026-08-10
- cycloplegic: False
- device_id: BIO-B
- spherical_equivalent_d: -4.625
- axial_length_mm: 25.54
- best_corrected_acuity_logmar: 0.0
- Annualized spherical-equivalent change: -0.3345
- Annualized axial-length change: 0.1271

## Requested baseline and missing-data closure
- **Monocular uncorrected and best-corrected visual acuity** — Separate optical blur from unexplained loss of best-corrected function.
- **Current refraction with method documented** — Provide usable correction and a comparable baseline.
- **Ocular-health examination** — Avoid treating every blur as uncomplicated refractive error.
- **Real-world visual-function goals** — Measure reading, education, work, mobility, night driving, comfort, and participation.
- **Cost, travel, time, adherence, and adverse-event burden** — Prevent a theoretically effective plan from failing in the patient's actual life.
- **Serial refraction and axial length when progression is suspected** — Adult onset or progression is possible and should not be dismissed solely because schooling ended.
- **Occupational and near-task exposure** — Align correction and monitoring with current demands.
- **Ocular-surface, tear-film, lid, and contact-lens assessment** — Treat reversible instability and detect corneal risk.

## Patient priorities
- Maintain stable vision for engineering work
- Understand whether progression is continuing
- Avoid unnecessary products

## Authority boundary
- No automatic diagnosis.
- No automatic prescription or dose selection.
- No automatic device exposure or surgical selection.
- A qualified human eye-care professional must examine and decide where clinical action is required.
