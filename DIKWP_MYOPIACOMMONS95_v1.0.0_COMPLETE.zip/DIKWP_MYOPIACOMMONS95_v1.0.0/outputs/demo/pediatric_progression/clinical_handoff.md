# DIKWP-MYOPIACOMMONS95 Clinical Handoff

> Decision support only. This document is not a diagnosis, prescription, regulatory determination, or emergency service.

- Patient identifier: `demo-child-001`
- Age: 10
- Country code: US
- Preferred language: English
- Urgency: **ROUTINE_OR_PLANNED**
- High-myopia risk context: **False**

## Urgency reasons
- No entered field triggered an emergency reason; missing information cannot rule out disease.

## Priority actions
- Establish a qualified, person-centred baseline for each eye rather than treating the two eyes as one average.
- Separate correction, functional recovery, progression management, structural disease, and access burden into different outcomes.
- Agree in writing on what will be measured, when it will be remeasured, and what would trigger continuation, change, referral, or stopping.

## Latest per-eye data
### OD
- date: 2026-08-01
- cycloplegic: True
- device_id: BIO-A
- spherical_equivalent_d: -3.0
- axial_length_mm: 24.69
- best_corrected_acuity_logmar: 0.0
- Annualized spherical-equivalent change: -0.7505
- Annualized axial-length change: 0.2902
### OS
- date: 2026-08-01
- cycloplegic: True
- device_id: BIO-A
- spherical_equivalent_d: -2.75
- axial_length_mm: 24.57
- best_corrected_acuity_logmar: 0.0
- Annualized spherical-equivalent change: -0.7505
- Annualized axial-length change: 0.2602

## Requested baseline and missing-data closure
- **Monocular uncorrected and best-corrected visual acuity** — Separate optical blur from unexplained loss of best-corrected function.
- **Current refraction with method documented** — Provide usable correction and a comparable baseline.
- **Ocular-health examination** — Avoid treating every blur as uncomplicated refractive error.
- **Real-world visual-function goals** — Measure reading, education, work, mobility, night driving, comfort, and participation.
- **Cost, travel, time, adherence, and adverse-event burden** — Prevent a theoretically effective plan from failing in the patient's actual life.
- **Cycloplegic refraction when clinically appropriate** — Reduce accommodation-related misclassification.
- **Axial length on a documented instrument when available** — Track ocular growth rather than relying on refraction alone.
- **Family, onset-age, outdoor, near-work, and prior-progression history** — Support risk stratification and shared decision-making.

## Patient priorities
- See the classroom board clearly
- Slow future progression
- Keep treatment affordable and safe

## Authority boundary
- No automatic diagnosis.
- No automatic prescription or dose selection.
- No automatic device exposure or surgical selection.
- A qualified human eye-care professional must examine and decide where clinical action is required.
