# Myopia Safety Card

## Seek immediate eye care now for

- A sudden increase in floaters.
- New flashes of light.
- A curtain, fixed shadow, or missing area of vision.
- Sudden or rapidly worsening vision loss.
- Penetrating or high-speed eye trauma.
- Chemical exposure to the eye.

Do not delay possible retinal-detachment care for massage, exercises, red-light exposure, contact-lens wear, online advice, or a routine appointment. Do not drive yourself. For chemical exposure, begin continuous clean-water irrigation while obtaining emergency help.

## Seek same-day qualified care for

- New central distortion, a central blind spot, or rapid one-eye central blur.
- Contact-lens wear with pain, redness, light sensitivity, discharge, or sudden blur.
- Severe eye pain or a red light-sensitive eye.

This card does not rule out other emergencies and is not a diagnosis.
