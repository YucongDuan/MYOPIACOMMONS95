# DIKWP-MYOPIACOMMONS95 Clinical Handoff

> Decision support only. This document is not a diagnosis, prescription, regulatory determination, or emergency service.

- Patient identifier: `demo-retinal-alarm-001`
- Age: 52
- Country code: BR
- Preferred language: English
- Urgency: **EMERGENCY_NOW**
- High-myopia risk context: **True**

## Urgency reasons
- Sudden or rapidly worsening loss of vision
- A curtain, fixed shadow, or new field defect
- A sudden increase in floaters or new flashes can accompany a retinal tear or detachment

## Priority actions
- Seek an eye doctor or emergency department immediately.
- Do not drive yourself. Stop contact-lens wear and do not delay care for exercises, massage, red-light exposure, or online advice.
- For chemical exposure, begin continuous clean-water irrigation immediately while obtaining emergency help.
- Carry or export prior refraction, axial-length, retinal, surgical, medication, allergy, and contact-lens records when available.
- After urgent disease has been addressed, return to the full lifelong myopia pathway rather than treating the emergency as the entire care plan.

## Latest per-eye data
### OD
- date: 2026-05-01
- cycloplegic: False
- device_id: BIO-D
- spherical_equivalent_d: -11.75
- axial_length_mm: 29.1
- best_corrected_acuity_logmar: 0.1
- Annualized spherical-equivalent change: None
- Annualized axial-length change: None
### OS
- date: 2026-05-01
- cycloplegic: False
- device_id: BIO-D
- spherical_equivalent_d: -11.125
- axial_length_mm: 28.9
- best_corrected_acuity_logmar: 0.08
- Annualized spherical-equivalent change: None
- Annualized axial-length change: None

## Requested baseline and missing-data closure
- **Monocular uncorrected and best-corrected visual acuity** — Separate optical blur from unexplained loss of best-corrected function.
- **Current refraction with method documented** — Provide usable correction and a comparable baseline.
- **Ocular-health examination** — Avoid treating every blur as uncomplicated refractive error.
- **Real-world visual-function goals** — Measure reading, education, work, mobility, night driving, comfort, and participation.
- **Cost, travel, time, adherence, and adverse-event burden** — Prevent a theoretically effective plan from failing in the patient's actual life.
- **Dilated peripheral retinal examination** — Assess tears, holes, lattice, detachment, and other peripheral findings in clinical context.
- **Macular assessment and OCT when indicated** — Assess myopic macular degeneration, neovascular, tractional, or other macular pathology.
- **Optic-nerve and glaucoma assessment** — Interpret pressure, disc appearance, OCT, fields, and longitudinal change without relying on one color code.
- **Preserve pre-surgery refraction and axial length** — Do not erase structural risk after LASIK, SMILE, ICL, or lens surgery.
- **Lens, presbyopia, contrast, glare, and task-distance assessment** — Separate cataract, presbyopia, ocular surface, retinal, optic-nerve, and correction contributions.

## Patient priorities
- Protect remaining sight

## Authority boundary
- No automatic diagnosis.
- No automatic prescription or dose selection.
- No automatic device exposure or surgical selection.
- A qualified human eye-care professional must examine and decide where clinical action is required.
