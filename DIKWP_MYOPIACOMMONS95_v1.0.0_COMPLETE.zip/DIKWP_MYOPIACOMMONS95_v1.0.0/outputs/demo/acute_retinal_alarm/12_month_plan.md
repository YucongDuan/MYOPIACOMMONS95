# Twelve-Month Myopia Care and Vision-Protection Plan

> The schedule is a planning scaffold. Urgent symptoms override every calendar date, and a qualified clinician determines examination and treatment frequency.

## 0 TO 14 DAYS
- Complete urgent triage and secure basic correction or referral.
- Collect prior records and establish per-eye baseline data.
- Identify unavailable measurements and access barriers without labeling them normal.

## 15 TO 45 DAYS
- Restore correctable clarity, ocular-surface stability, task-specific near or distance function, and safe contact-lens use.
- For progressing children or adolescents, compare evidence-based options with product and jurisdiction checks.
- For high myopia or unexplained reduced best-corrected vision, complete retinal, macular, and optic-nerve pathways.

## 46 TO 90 DAYS
- Confirm that the plan is usable, affordable, and acceptable in daily life.
- Record side effects, adherence, vendor claims, and conflicts of interest.
- Set the first outcome review and prewrite continuation, change, referral, and stopping criteria.

## 3 TO 12 MONTHS
- Repeat age- and risk-appropriate outcomes under comparable conditions.
- Evaluate absolute change, uncertainty, adverse events, function, and burden rather than one promotional percentage.
- Update the patient-owned passport and export records before changing clinic, product, country, or care team.

## LIFELONG
- Continue retinal, macular, optic-nerve, lens, ocular-surface, and functional surveillance according to personal risk.
- Retain high-myopia history after refractive surgery or apparent prescription normalization.
- Use vision rehabilitation promptly when function remains limited while continuing disease-directed care where appropriate.

## Outcome contract
- define outcomes before starting: True
- record absolute change: True
- record measurement uncertainty: True
- record adverse events and dropouts: True
- record cost and time burden: True
- prewrite stopping rules: True
- allow second opinion and data export: True
