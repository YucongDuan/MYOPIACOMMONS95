# DIKWP-MYOPIACOMMONS95 Clinical Handoff

> Decision support only. This document is not a diagnosis, prescription, regulatory determination, or emergency service.

- Patient identifier: `demo-post-surgery-001`
- Age: 45
- Country code: US
- Preferred language: English
- Urgency: **EXPEDITED_WITHIN_1_TO_2_WEEKS**
- High-myopia risk context: **True**

## Urgency reasons
- Persistent one-eye decline, distortion, new night-driving difficulty, or frequent prescription change merits an accelerated examination

## Priority actions
- Arrange the accelerated eye examination described in the triage output.
- Establish a qualified, person-centred baseline for each eye rather than treating the two eyes as one average.
- Separate correction, functional recovery, progression management, structural disease, and access burden into different outcomes.
- Agree in writing on what will be measured, when it will be remeasured, and what would trigger continuation, change, referral, or stopping.

## Latest per-eye data
### OD
- date: 2026-06-20
- cycloplegic: False
- device_id: BIO-E
- spherical_equivalent_d: -0.5
- axial_length_mm: 28.42
- best_corrected_acuity_logmar: 0.0
- Annualized spherical-equivalent change: None
- Annualized axial-length change: None
### OS
- date: 2026-06-20
- cycloplegic: False
- device_id: BIO-E
- spherical_equivalent_d: -0.25
- axial_length_mm: 28.2
- best_corrected_acuity_logmar: 0.0
- Annualized spherical-equivalent change: None
- Annualized axial-length change: None

## Requested baseline and missing-data closure
- **Monocular uncorrected and best-corrected visual acuity** — Separate optical blur from unexplained loss of best-corrected function.
- **Current refraction with method documented** — Provide usable correction and a comparable baseline.
- **Ocular-health examination** — Avoid treating every blur as uncomplicated refractive error.
- **Real-world visual-function goals** — Measure reading, education, work, mobility, night driving, comfort, and participation.
- **Cost, travel, time, adherence, and adverse-event burden** — Prevent a theoretically effective plan from failing in the patient's actual life.
- **Dilated peripheral retinal examination** — Assess tears, holes, lattice, detachment, and other peripheral findings in clinical context.
- **Macular assessment and OCT when indicated** — Assess myopic macular degeneration, neovascular, tractional, or other macular pathology.
- **Optic-nerve and glaucoma assessment** — Interpret pressure, disc appearance, OCT, fields, and longitudinal change without relying on one color code.
- **Preserve pre-surgery refraction and axial length** — Do not erase structural risk after LASIK, SMILE, ICL, or lens surgery.
- **Lens, presbyopia, contrast, glare, and task-distance assessment** — Separate cataract, presbyopia, ocular surface, retinal, optic-nerve, and correction contributions.

## Patient priorities
- Preserve long-term retinal safety
- Understand why a near-zero prescription does not erase prior high myopia
- Improve night vision

## Authority boundary
- No automatic diagnosis.
- No automatic prescription or dose selection.
- No automatic device exposure or surgical selection.
- A qualified human eye-care professional must examine and decide where clinical action is required.
