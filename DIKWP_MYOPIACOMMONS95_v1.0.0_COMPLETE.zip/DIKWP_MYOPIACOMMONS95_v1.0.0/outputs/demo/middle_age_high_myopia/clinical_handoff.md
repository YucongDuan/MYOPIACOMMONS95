# DIKWP-MYOPIACOMMONS95 Clinical Handoff

> Decision support only. This document is not a diagnosis, prescription, regulatory determination, or emergency service.

- Patient identifier: `demo-middle-high-001`
- Age: 49
- Country code: AU
- Preferred language: English
- Urgency: **EXPEDITED_WITHIN_1_TO_2_WEEKS**
- High-myopia risk context: **True**

## Urgency reasons
- Persistent one-eye decline, distortion, new night-driving difficulty, or frequent prescription change merits an accelerated examination

## Priority actions
- Arrange the accelerated eye examination described in the triage output.
- Establish a qualified, person-centred baseline for each eye rather than treating the two eyes as one average.
- Separate correction, functional recovery, progression management, structural disease, and access burden into different outcomes.
- Agree in writing on what will be measured, when it will be remeasured, and what would trigger continuation, change, referral, or stopping.

## Latest per-eye data
### OD
- date: 2026-06-15
- cycloplegic: False
- device_id: BIO-C
- spherical_equivalent_d: -10.0
- axial_length_mm: 28.17
- best_corrected_acuity_logmar: 0.05
- Annualized spherical-equivalent change: 0.0
- Annualized axial-length change: 0.02
### OS
- date: 2026-06-15
- cycloplegic: False
- device_id: BIO-C
- spherical_equivalent_d: -9.375
- axial_length_mm: 27.88
- best_corrected_acuity_logmar: 0.02
- Annualized spherical-equivalent change: 0.0
- Annualized axial-length change: 0.02

## Requested baseline and missing-data closure
- **Monocular uncorrected and best-corrected visual acuity** — Separate optical blur from unexplained loss of best-corrected function.
- **Current refraction with method documented** — Provide usable correction and a comparable baseline.
- **Ocular-health examination** — Avoid treating every blur as uncomplicated refractive error.
- **Real-world visual-function goals** — Measure reading, education, work, mobility, night driving, comfort, and participation.
- **Cost, travel, time, adherence, and adverse-event burden** — Prevent a theoretically effective plan from failing in the patient's actual life.
- **Dilated peripheral retinal examination** — Assess tears, holes, lattice, detachment, and other peripheral findings in clinical context.
- **Macular assessment and OCT when indicated** — Assess myopic macular degeneration, neovascular, tractional, or other macular pathology.
- **Optic-nerve and glaucoma assessment** — Interpret pressure, disc appearance, OCT, fields, and longitudinal change without relying on one color code.
- **Preserve pre-surgery refraction and axial length** — Do not erase structural risk after LASIK, SMILE, ICL, or lens surgery.
- **Ocular-surface, tear-film, lid, and contact-lens assessment** — Treat reversible instability and detect corneal risk.
- **Lens, presbyopia, contrast, glare, and task-distance assessment** — Separate cataract, presbyopia, ocular surface, retinal, optic-nerve, and correction contributions.

## Patient priorities
- Protect retinal and macular vision
- Improve computer and reading comfort
- Drive safely at night

## Authority boundary
- No automatic diagnosis.
- No automatic prescription or dose selection.
- No automatic device exposure or surgical selection.
- A qualified human eye-care professional must examine and decide where clinical action is required.
