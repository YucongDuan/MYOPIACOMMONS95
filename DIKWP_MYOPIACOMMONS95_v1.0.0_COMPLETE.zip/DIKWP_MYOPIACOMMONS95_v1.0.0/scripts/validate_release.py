from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(command: list[str]) -> None:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src")
    subprocess.run(command, cwd=ROOT, check=True, env=env)


def main() -> int:
    run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"])
    env_python = [sys.executable, "run.py"]
    run(env_python + ["doctor"])
    run(env_python + ["demo", "--out", "outputs/demo"])
    run(env_python + ["verify", "--out", "outputs/demo/pediatric_progression"])
    print(json.dumps({"valid": True, "root": str(ROOT)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
