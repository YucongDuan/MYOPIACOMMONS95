from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    for name in ("build",):
        shutil.rmtree(ROOT / name, ignore_errors=True)
    for path in (ROOT / "src").glob("*.egg-info"):
        shutil.rmtree(path, ignore_errors=True)
    subprocess.run([sys.executable, "-m", "pip", "wheel", ".", "--no-deps", "--no-build-isolation", "-w", "dist"], cwd=ROOT, check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
