# Governance

## Patient sovereignty

The patient or lawful guardian controls the local record, disclosure level, export, withdrawal, and research reuse. Access to the software does not authorize commercial reuse, identity simulation, insurer scoring, employer screening, or unrelated profiling.

## Protective asymmetry

The party with greater information, economic power, or technical capacity carries greater disclosure and explanation duties. A clinic, product vendor, platform, insurer, or Agent must not treat patient silence, urgency, low health literacy, or lack of alternatives as informed consent.

## Evidence discipline

Every claim should identify its population, product, comparator, outcomes, measurement method, duration, adverse events, discontinuation effects, jurisdiction, funding, and conflict-of-interest context. Negative and null results must remain visible.

## Human authority

Automatic diagnosis, prescription, dose selection, device control, surgical selection, payment, publication, and external action remain disabled. Material clinical decisions require a qualified human professional and the patient's informed participation.

## Open governance

Changes to evidence records, claim rules, schemas, and clinical boundaries should be versioned, reviewable, and reversible. No commercial sponsor receives silent control over outcome definitions or adverse-event reporting.
