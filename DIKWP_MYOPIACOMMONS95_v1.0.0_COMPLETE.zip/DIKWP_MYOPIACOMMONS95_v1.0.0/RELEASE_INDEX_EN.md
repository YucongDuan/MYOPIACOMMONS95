# DIKWP-MYOPIACOMMONS95 Release Index

## Start here

- `README.md` — installation, boundaries, and quick start.
- `docs/FULL_SYSTEM_REPORT_EN.md` — full system and evidence report.
- `docs/FULL_SYSTEM_REPORT_EN.html` — browser-readable report.
- `docs/GLOBAL_PATIENT_PATHWAY_EN.md` — practical global patient pathway.
- `outputs/demo/pediatric_progression/dashboard.html` — offline dashboard example.

## Patient and clinician tools

- `examples/patient_intake_template.json`
- `docs/CLINICAL_HANDOFF_AND_SECOND_OPINION_EN.md`
- `docs/ACCESS_EQUITY_PROTOCOL_EN.md`
- `docs/COMMERCIAL_BIAS_FIREWALL_EN.md`
- `docs/RESEARCH_AND_CLAIM_BOUNDARIES_EN.md`

Each compiled case creates a Myopia Passport, triage record, per-eye timeline, access plan, seven-lane risk map, care plan, jurisdiction gate, evidence registry, emergency card, twelve-month plan, home log, ledgers, and integrity manifest.

## Agent and interoperability tools

- `docs/AGENT_AND_AI_GATEWAY_EN.md`
- `schema/`
- compiled `mcp_tool_manifest.json`
- compiled `openapi.json`

## Synthetic demonstration cases

- progressing school-age child;
- progressing young adult;
- middle-aged high myopia;
- uncorrected myopia with severe access barriers;
- acute retinal alarm;
- high-myopia history after refractive surgery.

All demonstration data are synthetic.

## Verification

- `RELEASE_VALIDATION.json`
- `DIKWP_MYOPIACOMMONS95_v1.0.0_SHA256SUMS.txt` in the top-level distribution directory.
