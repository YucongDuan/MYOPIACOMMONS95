from __future__ import annotations

import unittest

from common import EXAMPLES
from dikwp_myopiacommons95.profile import life_stage, validate_profile
from dikwp_myopiacommons95.timeline import analyze_timeline, spherical_equivalent
from dikwp_myopiacommons95.utils import read_json


class ProfileTimelineTests(unittest.TestCase):
    def test_life_stages(self):
        self.assertEqual(life_stage(10), "SCHOOL_AGE_CHILD")
        self.assertEqual(life_stage(24), "YOUNG_ADULT")
        self.assertEqual(life_stage(49), "MIDDLE_AGE")

    def test_spherical_equivalent(self):
        self.assertEqual(spherical_equivalent({"sphere_d": -2.0, "cylinder_d": -1.0}), -2.5)

    def test_child_progression_timeline(self):
        profile = read_json(EXAMPLES / "pediatric_progression" / "profile.json")
        validate_profile(profile)
        timeline = analyze_timeline(profile)
        self.assertLessEqual(timeline["eyes"]["od"]["annualized_spherical_equivalent_change_d_per_year"], -0.7)
        self.assertGreaterEqual(timeline["eyes"]["od"]["annualized_axial_length_change_mm_per_year"], 0.28)

    def test_high_myopia_after_surgery_is_preserved(self):
        profile = read_json(EXAMPLES / "post_refractive_surgery_high_myopia" / "profile.json")
        self.assertTrue(analyze_timeline(profile)["high_myopia_risk_context"])

    def test_consent_required(self):
        profile = read_json(EXAMPLES / "pediatric_progression" / "profile.json")
        profile["consent"]["use_for_local_decision_support"] = False
        with self.assertRaises(ValueError):
            validate_profile(profile)


if __name__ == "__main__":
    unittest.main()
