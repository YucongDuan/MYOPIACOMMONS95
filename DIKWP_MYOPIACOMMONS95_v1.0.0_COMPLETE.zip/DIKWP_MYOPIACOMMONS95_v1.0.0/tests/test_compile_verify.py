from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from common import EXAMPLES
from dikwp_myopiacommons95.compiler import compile_profile
from dikwp_myopiacommons95.utils import read_json
from dikwp_myopiacommons95.verify import verify_output


class CompileVerifyTests(unittest.TestCase):
    def test_compile_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = compile_profile(EXAMPLES / "pediatric_progression" / "profile.json", tmp, source_date_epoch="1788393600")
            self.assertTrue(verify_output(tmp)["valid"])
            self.assertEqual(result["bundle"]["governance"]["automatic_prescription_authority"], 0)
            self.assertIsNone(result["bundle"]["claim_boundaries"]["permanent_axial_reversal_certificate"])

    def test_deterministic_content(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            first = compile_profile(EXAMPLES / "middle_age_high_myopia" / "profile.json", a, source_date_epoch="1788393600")
            second = compile_profile(EXAMPLES / "middle_age_high_myopia" / "profile.json", b, source_date_epoch="1788393600")
            self.assertEqual(first["bundle"]["compile_id"], second["bundle"]["compile_id"])
            self.assertEqual(first["bundle"]["content_digest"], second["bundle"]["content_digest"])

    def test_tampering_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            compile_profile(EXAMPLES / "pediatric_progression" / "profile.json", tmp, source_date_epoch="1788393600")
            path = Path(tmp) / "care_plan.json"
            path.write_text(path.read_text(encoding="utf-8") + "tamper", encoding="utf-8")
            result = verify_output(tmp)
            self.assertFalse(result["valid"])
            self.assertTrue(any("care_plan.json" in item for item in result["failures"]))

    def test_outputs_are_patient_owned_and_readable(self):
        with tempfile.TemporaryDirectory() as tmp:
            compile_profile(EXAMPLES / "post_refractive_surgery_high_myopia" / "profile.json", tmp, source_date_epoch="1788393600")
            passport = read_json(Path(tmp) / "myopia_passport.json")
            self.assertTrue(passport["rights"]["patient_owns_export"])
            self.assertTrue(passport["historical_high_myopia_must_be_preserved"])


if __name__ == "__main__":
    unittest.main()
