from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from dikwp_myopiacommons95.ledger import append_record, verify_ledger


class LedgerTests(unittest.TestCase):
    def test_append_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ledger.jsonl"
            append_record(path, {"outcome": "stable"}, "OUTCOME", source_date_epoch="1788393600")
            append_record(path, {"event": "none"}, "ADVERSE_EVENT_REVIEW", source_date_epoch="1788480000")
            result = verify_ledger(path)
            self.assertTrue(result["valid"])
            self.assertEqual(result["record_count"], 2)

    def test_tamper_detection(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ledger.jsonl"
            append_record(path, {"outcome": "stable"}, "OUTCOME", source_date_epoch="1788393600")
            path.write_text(path.read_text(encoding="utf-8").replace("stable", "changed"), encoding="utf-8")
            self.assertFalse(verify_ledger(path)["valid"])


if __name__ == "__main__":
    unittest.main()
