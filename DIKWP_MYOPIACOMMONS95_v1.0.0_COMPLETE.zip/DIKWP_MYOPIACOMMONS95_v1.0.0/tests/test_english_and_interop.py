from __future__ import annotations

import unittest
from pathlib import Path

from common import ROOT
from dikwp_myopiacommons95.interop import mcp_manifest, openapi_spec
from dikwp_myopiacommons95.utils import has_cjk


class EnglishInteropTests(unittest.TestCase):
    def test_release_sources_are_english_only(self):
        bad = []
        roots = [ROOT / "src", ROOT / "docs", ROOT / "examples", ROOT / "schema", ROOT / "config"]
        for base in roots:
            for path in base.rglob("*"):
                if path.is_file() and path.suffix in {".py", ".md", ".json", ".html", ".txt", ".csv"}:
                    if has_cjk(path.read_text(encoding="utf-8")):
                        bad.append(str(path.relative_to(ROOT)))
        self.assertEqual(bad, [])

    def test_interop_is_read_only(self):
        manifest = mcp_manifest()
        self.assertEqual(manifest["write_tools"], [])
        self.assertEqual(manifest["external_action_authority"], 0)
        spec = openapi_spec()
        self.assertEqual(spec["x-authority-boundaries"]["write_endpoints"], 0)


if __name__ == "__main__":
    unittest.main()
