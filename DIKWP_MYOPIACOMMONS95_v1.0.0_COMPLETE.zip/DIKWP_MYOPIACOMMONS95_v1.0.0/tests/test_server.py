from __future__ import annotations

import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from common import EXAMPLES
from dikwp_myopiacommons95.compiler import compile_profile
from dikwp_myopiacommons95.server import make_handler
from http.server import ThreadingHTTPServer


class ServerTests(unittest.TestCase):
    def test_read_only_server(self):
        with tempfile.TemporaryDirectory() as tmp:
            compile_profile(EXAMPLES / "pediatric_progression" / "profile.json", tmp, source_date_epoch="1788393600")
            server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(tmp))
            port = server.server_address[1]
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            time.sleep(0.05)
            try:
                with urlopen(f"http://127.0.0.1:{port}/health", timeout=2) as response:
                    payload = json.load(response)
                    self.assertTrue(payload["read_only"])
                request = Request(f"http://127.0.0.1:{port}/bundle", data=b"{}", method="POST")
                with self.assertRaises(HTTPError) as context:
                    urlopen(request, timeout=2)
                self.assertEqual(context.exception.code, 405)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
