from __future__ import annotations

import unittest

from common import EXAMPLES
from dikwp_myopiacommons95.access import build_access_plan
from dikwp_myopiacommons95.risk import build_risk_map
from dikwp_myopiacommons95.timeline import analyze_timeline
from dikwp_myopiacommons95.triage import triage_profile
from dikwp_myopiacommons95.utils import read_json


class TriageAccessRiskTests(unittest.TestCase):
    def test_retinal_alarm_is_emergency(self):
        profile = read_json(EXAMPLES / "acute_retinal_alarm" / "profile.json")
        triage = triage_profile(profile)
        self.assertEqual(triage["urgency"], "EMERGENCY_NOW")

    def test_low_resource_missing_tests_not_normal(self):
        profile = read_json(EXAMPLES / "low_resource_uncorrected_myopia" / "profile.json")
        triage = triage_profile(profile)
        access = build_access_plan(profile, triage)
        self.assertEqual(access["access_tier"], "A1_BASIC_REFRACTIVE_ACCESS")
        self.assertIn("AXIAL_LENGTH_UNAVAILABLE", access["barriers"])
        self.assertIn("DILATED_RETINAL_EXAM_UNAVAILABLE", access["barriers"])

    def test_progression_signal(self):
        profile = read_json(EXAMPLES / "young_adult_progression" / "profile.json")
        timeline = analyze_timeline(profile)
        risk = build_risk_map(profile, timeline)
        self.assertTrue(risk["progression_signal"])

    def test_no_symptom_data_does_not_diagnose(self):
        profile = read_json(EXAMPLES / "pediatric_progression" / "profile.json")
        triage = triage_profile(profile)
        self.assertTrue(triage["not_a_diagnosis"])


if __name__ == "__main__":
    unittest.main()
