from __future__ import annotations

import unittest

from common import EXAMPLES
from dikwp_myopiacommons95.audit import RULES, audit_claims
from dikwp_myopiacommons95.evidence import evidence_registry, intervention_registry, measurement_truth_contract
from dikwp_myopiacommons95.utils import read_json
from dikwp_myopiacommons95.research import structural_restoration_research_registry


class AuditEvidenceTests(unittest.TestCase):
    def test_all_synthetic_misleading_claims_are_flagged(self):
        claims = read_json(EXAMPLES / "claims" / "claims.json")["claims"]
        audits = audit_claims(claims)
        self.assertEqual(len(audits), 20)
        self.assertTrue(all(item["flagged"] for item in audits))

    def test_rule_count(self):
        self.assertEqual(len(RULES), 20)

    def test_registries_have_scope_boundaries(self):
        self.assertGreaterEqual(len(evidence_registry()), 17)
        interventions = intervention_registry()
        self.assertGreaterEqual(len(interventions), 12)
        self.assertTrue(all(item["structural_reversal_claim"] is False for item in interventions))
        self.assertEqual(len(measurement_truth_contract()), 12)
        registry = structural_restoration_research_registry()
        self.assertEqual(len(registry), 7)
        self.assertTrue(all(item["clinical_availability"] == "RESEARCH_ONLY" for item in registry))


if __name__ == "__main__":
    unittest.main()
