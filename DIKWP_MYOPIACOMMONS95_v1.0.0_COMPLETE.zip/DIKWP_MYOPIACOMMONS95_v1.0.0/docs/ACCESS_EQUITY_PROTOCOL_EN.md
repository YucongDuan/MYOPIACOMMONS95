# Global Access and Equity Protocol

## Purpose

Myopia care cannot be called successful when an accurate spectacle prescription, safe lens replacement, retinal examination, travel, or follow-up is unaffordable or unavailable. Access is therefore part of the clinical model rather than an administrative afterthought.

The protocol follows the five WHO SPECS 2030 pillars: Services, Personnel, Education, Cost, and Surveillance.

## Access tiers

### A0 — Emergency access

The person has an urgent retinal, traumatic, chemical, macular, corneal, or severe-pain signal. The priority is immediate qualified care, safe transport, and referral. Payment or registration friction should not delay triage.

### A1 — Basic refractive access

The person lacks usable, safe, affordable correction. The immediate goal is accurate refraction, durable spectacles, usable near vision where needed, and a pathway for eye-health examination. Premium add-ons must not displace basic sight.

### A2 — Diagnostic referral gap

The person needs a dilated examination, macular evaluation, optic-nerve assessment, or retinal specialist, but the service is unavailable locally. Create a consolidated referral packet and minimize repeat travel. Tele-ophthalmology can support triage or interpretation where lawful and appropriate, but it cannot replace urgent in-person retinal examination when detachment is possible.

### A3 — Monitoring gap

Axial length, cycloplegic refraction, standardized OCT, or comparable follow-up is unavailable. Use the best valid local measurements, record their limitations, and avoid fabricated precision. A provider must not advertise proven progression control while refusing to measure relevant outcomes.

### A4 — Comprehensive pathway available

Core correction, measurement, examination, referral, and follow-up are accessible. Even here, the system audits affordability, vendor lock-in, conflicts of interest, overtreatment, and patient data ownership.

## Equity requirements

- Basic correction, urgent safety information, and referral data must not be paywalled.
- A person without internet access receives printable and offline records.
- A person with limited health literacy receives plain-language explanations and teach-back, not reduced autonomy.
- A child, dependent adult, migrant, or low-income patient must not be enrolled into a costly long-term product because alternatives were withheld.
- Clinical necessity and optional convenience must be itemized separately.
- Total cost includes examination, device, replacement, medication, travel, missed work or school, emergency access, and expected duration.
- Public programmes should measure effective coverage: usable correction and quality, not only spectacles distributed.
- Aggregated research data require separate consent, de-identification, governance, and benefit sharing.

## Minimum-safe-care bundle

When resources are severely constrained, the platform prioritizes:

1. urgent symptom screening;
2. monocular visual acuity;
3. a competent refraction and affordable correction;
4. an eye-health examination within local capability;
5. clear referral triggers;
6. child safeguarding and educational function;
7. patient-owned written records;
8. a realistic follow-up plan.

This bundle is not a claim that advanced tests are unnecessary. It prevents the absence of advanced care from blocking basic sight and safety.
