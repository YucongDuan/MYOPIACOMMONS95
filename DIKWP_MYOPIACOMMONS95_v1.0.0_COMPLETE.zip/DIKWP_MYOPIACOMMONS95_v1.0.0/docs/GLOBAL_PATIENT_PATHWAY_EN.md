# Global Patient Pathway for Myopia

## 1. Immediate safety overrides every long-term plan

Seek immediate qualified eye care or an emergency department for a sudden increase in floaters, new flashes, a curtain or shadow, a new visual-field defect, sudden or rapidly worsening vision loss, penetrating or high-speed trauma, or chemical exposure. Do not delay possible retinal-detachment care for online advice, eye exercises, massage, red-light exposure, contact-lens wear, or a routine appointment.

Seek same-day qualified care for new central distortion, a central blind spot, rapid one-eye central blur, severe eye pain, a red light-sensitive eye, or contact-lens wear accompanied by pain, redness, light sensitivity, discharge, or sudden blur.

## 2. Build a per-eye truth baseline

A minimum useful record separates the right eye from the left and documents:

- uncorrected and best-corrected visual acuity;
- current refraction and whether cycloplegia was used;
- axial length, instrument, and date when available;
- ocular-surface and contact-lens status;
- lens and presbyopia status where relevant;
- dilated retinal and macular findings according to risk;
- optic-nerve, pressure, field, and OCT context where indicated;
- previous refractive, cataract, ICL, retinal, or glaucoma procedures;
- real-world tasks such as school, work, reading, mobility, and night driving;
- cost, travel, time, adherence, and adverse-event burden.

A missing test is not a normal test. The system records unavailability as a gap and creates a referral or minimum-safe-care pathway.

## 3. Separate five outcomes

### Optical correction

Spectacles, contact lenses, corneal refractive surgery, and lens-based surgery can improve focus. They do not automatically reverse axial elongation or eliminate retinal risk.

### Recoverable function

Treatable ocular-surface instability, accommodation or binocular disorders, task-distance mismatch, glare, presbyopia, and inaccurate correction may improve. Improvement should be measured with the relevant functional endpoint.

### Progression management

Evidence-based interventions can slow progression in selected children and adolescents, and adult progression deserves evaluation when present. Slowing is not guaranteed arrest, and one trial or product cannot be generalized globally.

### Disease and complication management

High myopia can require retinal, macular, glaucoma, lens, and low-vision pathways across the lifespan. Pathologic myopia is a structural disease classification, not merely a spectacle number.

### Experimental structural restoration

A claim of durable axial or posterior-segment restoration requires objective structural change beyond measurement uncertainty, appropriate controls, persistence after treatment withdrawal, preserved function, retinal and optic-nerve safety, independent replication, and acceptable burden. No routine permanent-reversal certificate is issued.

## 4. Life-stage pathway

### Infants and young children

Priorities include detection of amblyopia risk, strabismus, high or asymmetric refractive error, congenital or inherited disease, and family access to timely correction. A child is not a small adult; developmental visual needs and safeguarding apply.

### School-age children and adolescents

Use cycloplegic refraction when clinically appropriate, axial length when available, onset age, family history, outdoor and near-work context, and serial change. Compare evidence-based interventions only after exact product, age, fit, safety, cost, and jurisdiction checks. Prewrite follow-up and stopping rules.

### Young adults

Do not dismiss new or progressive myopia solely because formal schooling ended. Confirm the trend with comparable measurements, assess intensive near work and ocular-surface issues, and preserve retinal-risk assessment when myopia is high.

### Middle-aged adults

Separate presbyopia, cataract, ocular surface, macula, retina, optic nerve, and correction. High-myopia history remains relevant after LASIK, SMILE, ICL, or a near-zero current prescription. Measure real-world reading, computer, contrast, glare, and night-driving function.

### Older adults

Integrate myopia history with cataract, glaucoma, macular disease, retinal tears or detachment, diabetes, falls, medication, and vision rehabilitation. Treatment and rehabilitation can proceed together.

### People with uncorrected myopia or severe access barriers

Prioritize accurate, durable, affordable correction and urgent referral. Do not sell premium control technologies before basic sight, safety, and follow-up are feasible. Use printable, offline, patient-owned records. Where advanced measurement is unavailable, document uncertainty and never invent a normal result.

## 5. Treatment comparison contract

For any intervention, request a written answer to:

1. What exact outcome is intended: correction, function, refraction, axial length, structural disease, or participation?
2. Which product, formulation, concentration, device, or design was studied?
3. Which ages, baseline refractions, ethnic or geographic populations, and exclusion criteria were used?
4. What were the absolute changes in cycloplegic refraction and axial length?
5. What adverse events, dropouts, discontinuation effects, and rebound were observed?
6. Is the proposed use authorized, cleared, registered, or off-label in the local jurisdiction?
7. What lower-cost, lower-risk, or noncommercial alternatives exist?
8. What financial relationship does the clinic or recommender have with the product?
9. What will cause the plan to continue, change, stop, or be referred?
10. Can the patient export all raw measurements and reports?

## 6. Patient-owned monitoring

At each meaningful review, update:

- per-eye refraction and method;
- per-eye axial length and device;
- best-corrected acuity;
- retinal, macular, optic-nerve, lens, and ocular-surface status;
- treatment exposure, exact product, adherence, and stopping date;
- adverse events and symptoms;
- patient-prioritized function;
- total cost and time burden;
- the clinician's interpretation and uncertainty;
- the next review or urgent trigger.

The record travels with the patient. Changing clinic, product, country, insurer, or Agent must not erase the historical worldline.
