# Research and Claim Boundaries

## Current scientific boundary

The system does not treat established axial myopia as routinely and permanently reversible. It also refuses to turn the current absence of a proven reversal method into an eternal prohibition on research.

## Structural restoration research contract

A candidate restoration approach must pre-register:

- target tissue and proposed mechanism;
- inclusion and exclusion criteria;
- objective structural endpoint;
- instrument, repeatability, masking, and measurement uncertainty;
- separation of corneal, accommodative, choroidal, hydration, and diurnal effects;
- functional endpoints, including best-corrected acuity, contrast, field, symptoms, and real-world tasks;
- retinal, macular, optic-nerve, corneal, and systemic safety;
- control condition and alternative explanations;
- treatment withdrawal and durability period;
- adverse-event and dropout publication;
- independent replication threshold;
- patient cost, time, travel, and opportunity burden;
- conditions that retire the mechanism.

## Evidence status ladder

1. Mechanistic proposal.
2. Preclinical signal.
3. Early human feasibility.
4. Controlled clinical signal.
5. Replicated clinical effect.
6. Product- and population-specific clinical utility.
7. Jurisdiction-specific authorization or professional guidance.
8. Long-term effectiveness and safety in diverse real-world populations.

A claim cannot skip levels because the intervention is popular, technologically impressive, culturally resonant, or commercially successful.

## Priority open research questions

- Can scleral extracellular-matrix remodeling be altered safely without weakening the globe or harming retina and choroid?
- Which retinal, choroidal, scleral, circadian, and biomechanical signals are causal rather than correlational?
- Can individual response be predicted before exposure to a costly or risky intervention?
- How should progression be interpreted in adults and after refractive surgery?
- Which combinations add true benefit rather than cost and burden?
- How can outcome definitions become globally comparable while remaining usable in low-resource settings?
- What post-treatment durability and rebound occur across interventions?
- Which safety signals are hidden by short trials, selective follow-up, or product heterogeneity?

## Null and negative results

A null result is a contribution. The registry preserves failed mechanisms, lack of effect, intolerance, dropout, and commercial nonviability so that patients and researchers do not repeatedly pay for the same unrecorded failure.
