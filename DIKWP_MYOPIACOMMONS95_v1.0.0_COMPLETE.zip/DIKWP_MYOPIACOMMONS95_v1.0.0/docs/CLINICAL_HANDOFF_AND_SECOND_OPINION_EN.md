# Clinical Handoff and Second-Opinion Protocol

## One-page handoff structure

- local patient identifier and consent scope;
- age, country, life stage, occupation or school needs;
- urgent symptoms and onset time;
- right-eye and left-eye history;
- current and historical refraction with cycloplegia status;
- axial length with instrument and date;
- best-corrected acuity;
- retinal, macular, optic-nerve, lens, corneal, and ocular-surface findings;
- previous surgery, laser, injection, medication, and contact-lens exposure;
- exact current intervention and regulatory context;
- adverse events, adherence, burden, and patient goals;
- unresolved questions for the next professional.

## Second-opinion questions

1. What condition or risk is being treated, and what evidence supports that interpretation?
2. Which finding is objective, which is inferred, and which remains unknown?
3. What lower-risk, lower-cost, or reversible options exist?
4. What would happen if the person waits, observes, or uses standard correction?
5. What outcome will be measured, with which instrument, and after how long?
6. What is the absolute expected benefit, not only the relative percentage?
7. What adverse event requires stopping or emergency review?
8. Does the clinician, clinic, platform, or referrer have a financial interest?
9. Is the proposed use authorized locally or off-label?
10. Can all raw data and images be exported before treatment begins?

## Transfer rule

A new clinic or Agent must not delete the prior history because it disagrees with an earlier interpretation. It may add a new interpretation, cite evidence, and mark the earlier model as revised or retired while preserving the record.
