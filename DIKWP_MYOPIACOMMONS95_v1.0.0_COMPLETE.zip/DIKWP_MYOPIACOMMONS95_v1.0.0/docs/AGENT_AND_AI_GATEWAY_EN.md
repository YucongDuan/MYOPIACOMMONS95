# Agent and AI Gateway

DIKWP-MYOPIACOMMONS95 provides a read-only interface for other AI and Agent systems. The gateway is intended to improve continuity and evidence discipline, not to automate medical authority.

## Required Agent behavior

- Read emergency triage before discussing routine management.
- Distinguish patient-entered data, clinician findings, research evidence, regulatory records, and model inference.
- Never infer normality from an unavailable test.
- Never generate an atropine dose, light exposure, contact-lens fit, surgery, laser decision, or emergency reassurance.
- Never transfer product evidence across brands, countries, ages, formulations, or devices without verification.
- Preserve historical high-myopia context after refractive surgery.
- Explain translation and measurement loss when converting records.
- Protect patient data from unrelated commercial, employment, insurance, advertising, or identity uses.
- Make uncertainty, alternative models, adverse events, and stopping rules visible.
- Defer material clinical action to a qualified professional and the patient.

## Read-only tools

- read_myopia_passport
- read_triage
- read_care_plan
- read_evidence_registry
- audit_marketing_claim

No write, diagnosis, prescription, payment, publication, device-control, or identity authority is exposed.
