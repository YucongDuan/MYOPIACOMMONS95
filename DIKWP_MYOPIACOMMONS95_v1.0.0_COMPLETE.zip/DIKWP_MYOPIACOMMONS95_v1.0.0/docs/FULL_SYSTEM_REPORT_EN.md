# DIKWP-MYOPIACOMMONS95

## Global Myopia Recovery, Progression Management, High-Myopia Safety, Access Equity and Evidence Accountability OS

**Version:** 1.0.0  
**Evidence snapshot:** 3 September 2026  
**Language of this release:** English only  
**License:** Apache-2.0  
**Clinical authority:** Decision support only; no automatic diagnosis, prescription, dose selection, device control, surgery selection, payment, or external action.

---

## Executive summary

Myopia is often presented through a commercially convenient but clinically incomplete sequence: a person sees poorly at distance, receives glasses, contact lenses, surgery, medication, or a device, and is then told that vision has been corrected, controlled, restored, or cured. These words are not interchangeable.

DIKWP-MYOPIACOMMONS95 is an open-source global infrastructure that separates five different questions:

1. **Can the person see clearly with an appropriate optical correction?**
2. **Can reversible or compensable visual-function problems be improved?**
3. **Can current myopia progression or axial elongation be slowed?**
4. **Can retinal, macular, optic-nerve, lens, corneal, or ocular-surface complications be detected and treated in time?**
5. **Has a proposed intervention actually restored established axial or posterior-segment structure, durably and safely?**

The first four questions can often support real and substantial value. The fifth remains an open research question and must not be answered by advertising, unaided visual acuity, a short-term refraction change, temporary corneal reshaping, or a market authorization unrelated to permanent structural restoration.

The platform is also designed for the global access problem. The World Health Organization reported in February 2026 that at least 2.2 billion people live with near or distance vision impairment, at least 1 billion cases could have been prevented or remain unaddressed, and approximately two out of three people in low-income countries who need spectacles lack access to them. The system therefore treats affordability, provider distance, basic spectacle availability, examination capability, digital access, and referral capacity as clinical variables rather than as administrative footnotes.

The result is a patient-owned longitudinal Myopia Passport, an urgent safety engine, a per-eye measurement timeline, a life-stage care model, a high-myopia safety pathway, an access-equity planner, a product and jurisdiction gate, a commercial-claim auditor, append-only outcome and adverse-event ledgers, an offline dashboard, and read-only interfaces for other AI and Agent systems.

The reference implementation is deliberately unable to prescribe or act. Its purpose is to improve the truth conditions under which people, clinicians, programmes, researchers, and public institutions make decisions.

---

# 1. The global problem

## 1.1 Myopia is not only a spectacle problem

Myopia is a refractive state in which distant images focus in front of the retina without appropriate correction. In many people it is associated with an eye that has grown longer. A spectacle or contact lens can redirect light so that the image is focused more clearly. Corneal or lens surgery can also change optical power. These are valuable interventions, but they do not necessarily reverse the underlying ocular dimensions or erase future retinal and macular risk.

The International Myopia Institute distinguishes:

- **myopia correction**, which addresses optical blur;
- **myopia control**, which uses evidence-based interventions intended to slow progression and axial elongation;
- **myopia management**, which includes prevention, risk assessment, detection, correction, lifestyle, progression management, monitoring, and management of complications over the lifespan.

This distinction is the first invariant of the system. Every intervention, outcome, invoice, consent form, and Agent response must identify which layer it addresses.

## 1.2 The global burden is distributed unequally

A high-income urban patient may have access to cycloplegic refraction, biometry, corneal topography, OCT, retinal specialists, multiple optical designs, and longitudinal digital records. Another patient may not have an accurate pair of spectacles or a clinic within several hours of travel.

A system that only works where every measurement is available can deepen inequality. A system that pretends missing measurements do not matter can create false reassurance. DIKWP-MYOPIACOMMONS95 instead distinguishes:

- measured normal;
- measured abnormal;
- measured but unreliable;
- not measured;
- unavailable locally;
- unaffordable;
- unknown because the record cannot be retrieved.

These states remain separate through every downstream inference.

## 1.3 Knowledge abundance does not guarantee patient power

People can now find thousands of articles, advertisements, videos, clinical-trial summaries, and AI-generated recommendations. This apparent knowledge equality creates a new asymmetry: the patient receives more content, while the clinic, manufacturer, platform, or model still controls the outcome definition, product identity, regulatory language, and access to raw data.

A patient may be told that:

- unaided vision improved, therefore the eye recovered;
- a prescription became less negative, therefore axial length shortened;
- one branded lens worked, therefore every lens in the category works;
- a device is registered, therefore long-term safety and efficacy are settled;
- refractive surgery removed the need for high-myopia surveillance;
- a null response reflects poor adherence, attitude, or belief;
- an unavailable axial-length measurement means the eye is stable.

The platform is built to make these semantic substitutions visible.

---

# 2. Mesh95 operating principles

DIKWP-MYOPIACOMMONS95 uses the following operating stance:

`MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE`

This produces six design requirements.

## 2.1 Factual objectivity

Evidence status, uncertainty, adverse events, null findings, and contradictory trials must remain visible. A patient-protective position does not permit false medical promises.

## 2.2 Protective non-pseudoneutrality

The system is not neutral between a patient who carries risk and a seller who can define success after the fact. The more powerful party carries a greater duty to disclose alternatives, limitations, costs, conflicts, and failure criteria.

## 2.3 Patient agency

The patient owns the portable record, can refuse optional uses, can export data, can seek a second opinion, and can stop or change a plan. A signature obtained under urgency or lack of alternatives is not treated as unlimited consent.

## 2.4 Multiple non-isomorphic models

Blur may arise from refraction, ocular surface, accommodation, binocular function, cataract, retina, macula, optic nerve, neurological disease, or a combination. A single model cannot silently absorb all findings.

## 2.5 Reality-contact closure

A plan is not complete when treatment begins. It must return to measured outcomes, patient function, adverse events, cost, adherence, discontinuation, and revised interpretation.

## 2.6 Model revision and retirement

An intervention, mechanism, product claim, or clinical interpretation can be revised or retired. The earlier state remains in the append-only record so that history is not rewritten.

---

# 3. The eight-domain recovery model

The system refuses to output a single “recovery percentage.” It builds an eight-domain vector.

## 3.1 Optical clarity

This domain asks whether the person can obtain accurate and usable correction for distance, intermediate, and near tasks. It includes monocular and binocular performance, anisometropia, astigmatism, prescription tolerance, and real-world needs.

**Possible improvement:** often substantial.  
**Prohibited inference:** clearer vision proves structural reversal.

## 3.2 Accommodation and binocular function

Some people have a measurable accommodation, convergence, eye-alignment, or binocular coordination disorder. A diagnosis-specific intervention may improve symptoms and function.

**Possible improvement:** when a specific disorder is identified and an appropriate endpoint improves.  
**Prohibited inference:** generic eye training reverses axial myopia.

## 3.3 Ocular surface and tear-film stability

Dry eye, lid disease, contact-lens intolerance, exposure, and unstable tear film can produce fluctuating blur, burning, discomfort, or reduced visual quality.

**Possible improvement:** often meaningful.  
**Prohibited inference:** better tear-film optics mean axial length shortened.

## 3.4 Myopia progression and axial elongation

In selected children and adolescents, evidence-based optical and pharmacological interventions can slow progression. Onset or progression can also occur in young adulthood, although the evidence base is less extensive.

**Possible improvement:** a lower rate of change than an appropriate comparator or expected natural history.  
**Prohibited inference:** every person will stop progressing, or a population average predicts the individual exactly.

## 3.5 Established axial and posterior-segment structure

This domain records axial length, posterior-segment morphology, and structural disease. It is the domain most frequently overclaimed.

**Current routine claim boundary:** no permanent axial-reversal certificate.  
**Research status:** open, provided that objective, durable, safe, controlled, and independently replicated evidence is produced.

## 3.6 Complication prevention and treatment

High and pathologic myopia can be associated with retinal tears or detachment, myopic macular degeneration, macular neovascularization, tractional changes, glaucoma complexity, and other visual risks.

**Possible value:** earlier detection, disease-specific treatment, preserved function, and reduced delay.  
**Prohibited inference:** a current normal visit makes future risk zero.

## 3.7 Function, participation, and rehabilitation

Acuity does not capture reading endurance, contrast, glare, side vision, mobility, education, employment, or independence. Vision rehabilitation is not surrender; it is a parallel pathway that maximizes function while disease-directed care continues where appropriate.

## 3.8 Access and burden

A plan can fail because of cost, travel, replacement, time, school absence, work loss, discomfort, complexity, or lack of emergency access. These outcomes are measured alongside clinical outcomes.

---

# 4. Safety architecture

## 4.1 Emergency signals

The system places the following signals above every routine recommendation:

- sudden increase in floaters;
- new flashes;
- curtain, fixed shadow, or new visual-field defect;
- sudden or rapidly worsening vision loss;
- penetrating or high-speed trauma;
- chemical exposure.

The National Eye Institute states that these can be symptoms of retinal detachment and that people should seek an eye doctor or emergency department immediately. The software therefore never offers reassurance, exercises, massage, red-light exposure, or routine follow-up in place of urgent care.

## 4.2 Same-day signals

New central distortion, central scotoma, rapid one-eye central blur, severe eye pain, a red light-sensitive eye, or pain/redness/light sensitivity/discharge during contact-lens wear triggers same-day qualified care.

## 4.3 The missing-data rule

The triage engine can only respond to entered information. It explicitly states that missing or false fields do not rule out an emergency. A low-risk output is not a medical clearance.

## 4.4 Read-only Agent interface

Other AI systems can read triage output but cannot change it, dismiss it, or trigger treatment. The reference HTTP interface accepts GET requests only and returns HTTP 405 for write operations.

---

# 5. Per-eye longitudinal truth

## 5.1 Why each eye is separate

The right and left eyes may differ in refraction, axial length, acuity, retinal status, glaucoma suspicion, surgery, and treatment response. Averaging the two can hide clinically important asymmetry.

The system therefore stores each measurement as:

`<date, eye, refraction, cycloplegia status, axial length, device, acuity, examination context>`

## 5.2 Spherical equivalent

Spherical equivalent is calculated as sphere plus one-half cylinder. It is useful for summarization but never replaces the full prescription, visual acuity, or clinical examination.

## 5.3 Comparable axial length

Longitudinal axial analysis requires attention to instrument, repeatability, interval, and conditions. The reference implementation only calculates an annualized axial trend when the first and last entries use the same documented device.

## 5.4 Cycloplegia

In children and accommodation-sensitive cases, non-cycloplegic refraction can overstate myopia or obscure change. The platform records method and prevents a non-cycloplegic series from being represented as equivalent to a cycloplegic series.

## 5.5 Historical high myopia after surgery

LASIK, PRK, SMILE, ICL, and lens surgery can change current refraction. They do not automatically shorten a previously long eye or delete prior retinal risk. The Myopia Passport permanently preserves historical high-myopia context when the patient records it.

---

# 6. Life-stage pathways

## 6.1 Early childhood

The early-childhood pathway prioritizes visual development, amblyopia risk, strabismus, high or asymmetric refractive error, inherited or congenital disease, and timely access to correction. Product commercialization must not displace developmental safeguarding.

## 6.2 School-age children

The school-age pathway combines:

- cycloplegic refraction when clinically appropriate;
- axial length when available;
- age at onset;
- family history;
- prior rate of change;
- outdoor and near-work context;
- binocular and ocular-surface status;
- affordability and adherence;
- exact product and jurisdiction verification.

The system presents intervention classes for clinician discussion but never chooses a drug concentration, contact-lens fit, red-light exposure, or product.

## 6.3 Adolescents

Adolescents require continued progression monitoring, independent participation in consent, contact-lens safety, education and screen demands, sports and occupation needs, and a transition plan into adult eye care.

## 6.4 Young adults

The International Myopia Institute has documented that onset and progression can occur between 18 and 40 years. Young adults with changing refraction should not be dismissed automatically. The platform looks for comparable measurements, occupational intensity, ocular-surface effects, pregnancy or medication context where clinically relevant, and high-myopia risk.

## 6.5 Middle age

Middle-aged patients often experience several overlapping transitions: presbyopia, changing task distance, ocular-surface instability, cataract, glare, retinal or macular disease, and glaucoma assessment complexity. The system requires these models to remain separate until evidence connects them.

## 6.6 Older adulthood

Older adults need integrated care across refractive correction, cataract, retinal disease, glaucoma, diabetes, fall risk, medication, low vision, and rehabilitation. A narrow “myopia control” product is not a sufficient lifelong plan.

---

# 7. Intervention governance

## 7.1 Accurate spectacle correction

Accurate, durable, affordable spectacles remain a foundational global intervention. Basic correction should precede premium add-ons when a person cannot see adequately for school, work, or mobility.

The platform rejects intentional undercorrection as a generic recovery strategy.

## 7.2 Myopia-control spectacle lenses

Clinical trials support specific lens designs for selected children. The International Myopia Institute's 2025 intervention review identified multiple randomized trials and meaningful axial-length effects. The platform still requires exact product identification, age and refractive scope, adaptation, adverse effects, cost, and local regulatory verification.

A branded study result is not a class certificate for every lens using terms such as defocus, peripheral focus, or myopia management.

## 7.3 Soft contact lenses

Specific soft contact-lens designs have evidence and, in some jurisdictions, product-specific indications. Contact-lens care also introduces corneal infection risk, hygiene requirements, replacement schedules, and dependence on reliable supplies.

The system does not infer that a product authorized in the United States has the same indication elsewhere.

## 7.4 Orthokeratology

Orthokeratology can temporarily reshape the cornea to improve unaided daytime vision and has evidence for slowing axial elongation in selected children. It requires specialist fitting, topography, hygiene, follow-up, and emergency access.

The system records unaided visual improvement and axial trend separately. It never calls temporary corneal reshaping permanent biological recovery.

## 7.5 Low-concentration atropine

Atropine evidence is heterogeneous. A United States randomized trial of 0.01% did not slow progression or axial elongation compared with placebo, while other trials and formulations reported positive signals. Concentration, formulation, population, adherence, duration, side effects, and stopping effects matter.

The platform therefore provides no universal dose and no country-independent recommendation. It requires a qualified prescriber and exact local verification.

## 7.6 Repeated low-level red-light therapy

RLRL studies have reported short-term efficacy signals, predominantly in East Asian children. The 2025 International Myopia Institute review also highlighted rebound values in some red-light studies. A 2025 cohort study reported lower paracentral cone density and subtle retinal abnormalities in some users, supporting further long-term safety research.

The system places RLRL in a research or tightly governed specialist pathway. It requires exact device identity, wavelength, exposure, retinal dosimetry, regulatory status, adverse-event monitoring, and discontinuation follow-up. No device-independent safety or permanent-restoration claim is permitted.

## 7.7 Refractive surgery

Refractive surgery may reduce dependence on spectacles or contact lenses. It does not certify that high myopia has been biologically cured. The system preserves preoperative refraction, axial length, retinal history, and future surveillance needs.

## 7.8 Disease-specific and rehabilitative care

Retinal, macular, glaucoma, cataract, corneal, or ocular-surface disease requires disease-specific examination and treatment. Vision rehabilitation supports function when impairment remains. These pathways are not competitors; they can be combined.

---

# 8. Global access architecture

## 8.1 WHO SPECS 2030 alignment

The access engine is organized around five pillars:

- **Services:** a usable pathway from basic correction to referral;
- **Personnel:** appropriately trained people at each level;
- **Education:** comprehensible information and urgent warning recognition;
- **Cost:** transparent, affordable, sustainable care;
- **Surveillance:** outcomes, quality, unmet need, and safety reporting.

## 8.2 Five access tiers

### A0 — Emergency access

Immediate qualified care is required. The platform prioritizes safe transport and a referral-capable facility.

### A1 — Basic refractive access

The person cannot obtain usable correction. The platform prioritizes competent refraction, durable spectacles, near-vision needs, and a basic eye-health pathway.

### A2 — Diagnostic referral gap

The person needs retinal, macular, optic-nerve, or other specialist capability not available locally. A consolidated record reduces repeated travel.

### A3 — Monitoring gap

The person can receive care but lacks key progression or structural measurements. The system records uncertainty and prevents unsupported efficacy claims.

### A4 — Comprehensive pathway available

The core pathway exists, but commercial bias, data lock-in, overtreatment, and cost remain auditable.

## 8.3 Low-resource operation

The core uses the Python standard library, works offline, produces printable documents, and does not require a cloud model. It can preserve a patient record on a basic computer or transferable storage.

## 8.4 Public-health deployment

A public programme can aggregate de-identified metrics only under separate governance. Useful indicators include:

- proportion receiving usable correction;
- time from urgent signal to qualified care;
- proportion of children with method-documented refraction;
- progression follow-up completion;
- high-myopia retinal and macular pathway coverage;
- adverse-event reporting completeness;
- total patient cost and travel burden;
- record portability;
- effective rather than nominal coverage.

---

# 9. The patient-owned Myopia Passport

The passport is not a legal identity document or diagnosis. It is a portable continuity object containing:

- local patient identifier;
- age, country, preferred language, and consent scope;
- latest per-eye measurements;
- progression and high-myopia context;
- prior refractive surgery and historical high myopia;
- risk lanes;
- priority actions;
- requested clinical documents;
- claim boundaries;
- ownership and reuse rights;
- a deterministic content digest.

## 9.1 Selective disclosure

The patient can maintain a private local passport and export a clinician-handoff subset. Research reuse requires separate consent. Public availability of the software never grants access to the patient's data.

## 9.2 Anti-lock-in rule

The patient can export measurements, images, reports, treatment exposure, adverse events, and interpretations before changing clinic, country, insurer, or product.

## 9.3 Continuity after disagreement

A new clinician may disagree with an earlier interpretation. The new interpretation is appended with evidence; the prior record is not silently deleted.

---

# 10. Measurement truth contract

The system contains twelve measurement contracts. Each states what an endpoint can and cannot establish.

Examples:

- **Unaided acuity** can show current performance without correction but cannot prove axial shortening.
- **Best-corrected acuity** can quantify high-contrast acuity but cannot exclude field loss, contrast loss, retinal disease, or optic neuropathy.
- **Cycloplegic refraction** can reduce accommodation-related distortion but cannot assess peripheral retinal safety.
- **Axial length** can track ocular length under a defined protocol but cannot explain every cause of vision loss.
- **Corneal topography** can show reshaping but cannot prove posterior structural recovery.
- **OCT** can show a scanned cross-section but cannot replace the entire clinical examination.
- **Patient-reported function** can show real-world value but cannot by itself prove an anatomical mechanism.
- **Cost and burden** can show feasibility and inequity but cannot prove efficacy.

The contract prevents one favorable metric from swallowing the rest of the patient's reality.

---

# 11. Commercial and scientific claim audit

The reference auditor includes twenty rule families. They detect language associated with:

- permanent axial reversal;
- clearer vision equated with cure;
- surgery claimed to erase risk;
- undercorrection promoted as recovery;
- generic eye exercises promoted as axial cure;
- one-size-fits-all atropine;
- RLRL declared completely safe;
- class-wide transfer of a branded product result;
- CE marking equated with efficacy;
- refraction-only success claims;
- axial length treated as the whole eye;
- outdoor time claimed to cure established myopia;
- supplements claimed to reverse myopia;
- denial of cycloplegic assessment in children;
- denial of retinal follow-up after high myopia or surgery;
- patient blame;
- hidden exclusivity or urgency pressure;
- online delay of retinal emergencies;
- missing measurements treated as normal;
- one-country authorization treated as global.

The auditor is a screening tool, not a legal or regulatory judgment. A flagged claim requires human review and source verification.

---

# 12. Jurisdiction gate

Myopia products and professional practice differ across countries. The jurisdiction module therefore returns:

`LOCAL_PRODUCT_AND_INDICATION_VERIFICATION_REQUIRED`

for every profile.

It may identify an official regulatory portal, but it does not claim to maintain a complete, continuously synchronized global database.

The verification checklist includes:

- exact product or device model;
- exact formulation and concentration;
- intended age and refractive range;
- indication and outcome language;
- prescriber, fitter, or supervision requirements;
- warnings and post-market safety information;
- whether use is on-label or off-label;
- whether evidence belongs to the same product and population.

United States records for MiSight 1 Day and specific Stellest lenses are included as examples of product-specific regulatory scope, not as global endorsements.

---

# 13. Outcome, adverse-event, and consent ledgers

The system provides three empty local ledgers:

- `outcome_ledger.jsonl`;
- `adverse_event_ledger.jsonl`;
- `consent_ledger.jsonl`.

Each new record includes:

- record type;
- timestamp;
- previous-record hash;
- payload;
- current-record hash.

This makes silent alteration detectable. It does not replace clinical record law, digital signatures, or production-grade health information systems.

The ledgers can preserve:

- baseline and follow-up outcomes;
- adherence and discontinuation;
- adverse events;
- cost and time burden;
- consent changes;
- reasons for switching or stopping;
- model revision.

Negative results remain part of the evidence worldline.

---

# 14. AI and Agent gateway

The platform opens a controlled channel for other AI systems to understand a person's myopia care without granting them medical authority.

## 14.1 Available read-only capabilities

- read the Myopia Passport;
- read triage output;
- read the care plan;
- read the evidence registry;
- screen a marketing claim.

## 14.2 Agent prohibitions

An Agent must not:

- diagnose retinal detachment or reassure that it is absent;
- generate atropine concentration or dosing;
- set red-light wavelength, power, distance, or exposure;
- fit contact lenses;
- choose surgery or preventive retinal laser;
- infer approval in one country from approval in another;
- infer that a missing test is normal;
- erase historical high-myopia risk after refractive surgery;
- use the data for advertising, insurance, employment, identity simulation, or unrelated scoring;
- impersonate a clinician or the patient.

## 14.3 Translation and semantic loss

A global deployment may translate patient-facing material, but the current release is English only. Future translations must preserve:

- urgency level;
- exact measurement units;
- eye laterality;
- claim status;
- product identity;
- uncertainty;
- consent scope;
- local clinical terminology.

Translation loss must be recorded rather than hidden.

---

# 15. Technical architecture

## 15.1 Local-first core

The core is implemented in Python 3.10 or later using the standard library. It does not require:

- a database;
- a cloud account;
- an external model API;
- telemetry;
- analytics;
- a payment system;
- an internet connection for local compilation.

## 15.2 Input

The main input is a JSON profile containing:

- local identifier;
- age and country;
- consent;
- goals;
- symptoms;
- history;
- access conditions;
- serial per-eye measurements.

## 15.3 Output

A compiled case contains:

- complete bundle;
- triage;
- timeline;
- access plan;
- risk map;
- care plan;
- Myopia Passport;
- jurisdiction policy;
- evidence and intervention registries;
- measurement truth contract;
- MCP manifest;
- OpenAPI document;
- clinical handoff;
- emergency card;
- twelve-month plan;
- home monitoring CSV;
- empty append-only ledgers;
- offline dashboard;
- verification receipt;
- file manifest with SHA-256 hashes.

## 15.4 Deterministic identity

The system creates a content digest from deterministic inputs and outputs, then derives a compilation identifier. Recompiling the same profile and evidence snapshot under the same software version produces the same identifier, excluding generation time.

## 15.5 Integrity verification

The verifier checks:

- required files;
- content digest;
- compilation identifier;
- file hashes;
- unexpected unmanifested files;
- zero medical and external-action authority;
- absence of a permanent-reversal certificate.

---

# 16. Reference scenarios

The release includes six synthetic scenarios.

## 16.1 Progressing school-age child

Serial cycloplegic refraction and same-device axial length show a progression signal. The output supports a product-specific clinician discussion and longitudinal outcome contract without choosing treatment.

## 16.2 Progressing young adult

Serial measurements and prescription change create an adult-progression review. Ocular-surface symptoms, contact-lens use, cost, and occupational function are integrated.

## 16.3 Middle-aged high myopia

Long axial length, high refraction, night-driving difficulty, ocular-surface symptoms, and glaucoma context trigger retinal, macular, optic-nerve, lens, presbyopia, and functional pathways.

## 16.4 Uncorrected myopia with severe access barriers

No axial length, no cycloplegic service, no retinal specialist, poor internet, long travel, affordability barrier, and lack of safe spectacles produce an A1 basic-access priority. Missing advanced tests are not labeled normal.

## 16.5 Acute retinal alarm

Flashes, sudden floaters, curtain, and sudden vision loss trigger `EMERGENCY_NOW`. Routine management is subordinated to emergency care.

## 16.6 High-myopia history after refractive surgery

A near-zero current refraction does not erase a historical refraction around -10 D and axial length above 28 mm. The passport preserves the structural-risk context.

All cases are synthetic and are not real patient recommendations.

---

# 17. Open-source commercialization without value extraction

The core should remain free for patients, public-health programmes, educators, researchers, and basic local deployment. Sustainable commercial services can include:

- secure hosted deployment;
- regulated health-system integration;
- validated translation and accessibility packages;
- clinician workflow integration;
- national regulatory connectors;
- device and product registry maintenance;
- de-identified surveillance under public governance;
- training and implementation support;
- independent evidence audits;
- quality assurance and security operations.

Commercial revenue must not depend on ranking affiliated products, hiding free alternatives, selling patient data, or redefining success after the fact.

A production service should publish:

- ownership and funding;
- clinical governance;
- data use;
- product relationships;
- model changes;
- security incidents;
- audit results;
- adverse-event handling;
- pricing and exit rights.

---

# 18. Validation strategy

The release validation tests:

- profile validation and consent;
- life-stage classification;
- spherical-equivalent and longitudinal calculations;
- high-myopia context after surgery;
- retinal emergency triage;
- access-gap handling;
- progression signals;
- all twenty synthetic misleading claims;
- evidence and intervention boundaries;
- deterministic compilation;
- manifest verification and tamper detection;
- patient-owned export rights;
- append-only ledger integrity;
- read-only HTTP behavior;
- English-only source scan;
- zero write and external-action authority.

Software tests demonstrate implementation behavior. They do not establish clinical sensitivity, specificity, effectiveness, medical-device status, or permanent myopia reversal.

---

# 19. Limitations

1. The system has not been clinically validated as a diagnostic or treatment-selection device.
2. Patient-entered symptoms and measurements can be incomplete or wrong.
3. The evidence registry is dated and must be updated.
4. The regulatory portal map is not a complete global authorization database.
5. Thresholds used for navigation are not universal diagnostic laws.
6. Treatment effectiveness varies across people, products, studies, and settings.
7. The claim auditor uses transparent pattern rules and can miss misleading language or flag benign text.
8. The reference API lacks production authentication, encryption, health-system certification, and public-network hardening.
9. The English-only release does not solve language access; validated translations remain a roadmap requirement.
10. No software output can replace examination when retinal detachment, macular disease, glaucoma, infection, trauma, or another eye disease is possible.

---

# 20. Roadmap

## Phase 1 — Open patient infrastructure

- validated English release;
- patient passport;
- basic global access pathways;
- transparent evidence and claim audit;
- synthetic test cases;
- offline deployment.

## Phase 2 — Translation and regional co-governance

- clinically reviewed translations;
- right-to-left and low-literacy interfaces;
- regional terminology maps;
- national regulatory connectors;
- disability accessibility;
- local referral directories.

## Phase 3 — Clinical and public-health validation

- prospective usability studies;
- emergency-rule validation;
- clinician agreement studies;
- patient comprehension and agency outcomes;
- access and cost outcomes;
- adverse-event reporting completeness;
- deployment in low-resource and high-resource settings.

## Phase 4 — Federated outcome commons

- separately consented de-identified outcome data;
- intervention-specific, jurisdiction-specific, and population-specific analysis;
- negative-result preservation;
- independent governance;
- public audit of commercial conflicts;
- no sale of identifiable patient data.

## Phase 5 — Structural restoration research commons

- pre-registration;
- standardized truth contracts;
- open protocols;
- negative and adverse-event publication;
- independent replication;
- patient representation;
- explicit retirement of failed mechanisms.

---

# 21. Final value proposition

The system does not tell every person that myopia is permanently irreversible, and it does not sell a false cure.

It creates a more demanding and more hopeful contract:

- recover optical clarity where it can be recovered;
- treat reversible visual-function problems when they are present;
- slow progression where evidence and local clinical judgment support it;
- detect and treat sight-threatening complications early;
- protect high-myopia patients throughout life, including after refractive surgery;
- provide rehabilitation when function is limited;
- make access, cost, adverse events, and commercial interests visible;
- preserve patient ownership and continuity;
- keep structural restoration open as a rigorous, falsifiable research programme.

The patient is no longer only a consumer of correction. The patient becomes the owner of a verifiable visual worldline, a participant in decisions, and—under separate consent—a contributor to an open evidence commons that can improve care for others.

---

# References and evidence entry points

1. World Health Organization. *Blindness and vision impairment*. 10 February 2026. https://www.who.int/news-room/fact-sheets/detail/blindness-and-visual-impairment
2. World Health Organization. *Millions lack access to basic eyeglasses*. 22 May 2025. https://www.who.int/news/item/22-05-2025-millions-lack-access-to-basic-eyeglasses
3. International Myopia Institute. *Myopia Correction, Myopia Control and Myopia Management: Definitions and Recommended Usage*. https://myopiainstitute.org/imi-whitepaper/imi-myopia-correction-myopia-control-and-myopia-management-definitions-and-recommended-usage/
4. International Myopia Institute. *Interventions for Controlling Myopia Onset and Progression 2025*. https://myopiainstitute.org/imi-whitepaper/imi-interventions-for-controlling-myopia-onset-and-progression-2025/
5. International Myopia Institute. *Clinical Management Myopia Guidelines Report*. https://myopiainstitute.org/imi-whitepaper/clinical-management-myopia-guidelines-report/
6. International Myopia Institute. *Defining and Classifying Myopia*. https://myopiainstitute.org/imi-whitepaper/defining-and-classifying-myopia-a-proposed-set-of-standards-for-clinical-and-epidemiologic-studies/
7. National Eye Institute. *Retinal Detachment*. https://www.nei.nih.gov/eye-health-information/eye-conditions-and-diseases/retinal-detachment
8. Repka MX, et al. *Low-Dose 0.01% Atropine Eye Drops vs Placebo for Myopia Control*. PubMed 37440213. https://pubmed.ncbi.nlm.nih.gov/37440213/
9. Zadnik K, et al. *Efficacy and Safety of 0.01% and 0.02% Atropine for Pediatric Myopia Progression*. PubMed 37261839. https://pubmed.ncbi.nlm.nih.gov/37261839/
10. Yam JC, et al. *Low-Concentration Atropine for Myopia Progression*. PubMed 30514630. https://pubmed.ncbi.nlm.nih.gov/30514630/
11. Liao X, et al. *Cone Density Changes After Repeated Low-Level Red Light Treatment in Children With Myopia*. PubMed 40272813. https://pubmed.ncbi.nlm.nih.gov/40272813/
12. Cochrane. *Interventions for myopia control in children: a living systematic review and network meta-analysis*. PubMed 39945354. https://pubmed.ncbi.nlm.nih.gov/39945354/
13. US Food and Drug Administration. *MiSight 1 Day Premarket Approval record*. https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfpma/pma.cfm?id=P180035
14. US Food and Drug Administration. *FDA authorizes marketing of first eyeglass lenses to slow progression of pediatric myopia*. 25 September 2025. https://www.fda.gov/news-events/press-announcements/fda-authorizes-marketing-first-eyeglass-lenses-slow-progression-pediatric-myopia
15. National Eye Institute. *Vision Rehabilitation*. https://www.nei.nih.gov/eye-health-information/vision-rehabilitation
