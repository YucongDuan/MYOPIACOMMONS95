# Commercial Bias Firewall

## Why it exists

The system does not assume that clinicians or manufacturers act in bad faith. It does assume that asymmetry matters: the seller knows more about the product, controls the terminology, may select the outcome, and may profit while the patient carries cost, inconvenience, adverse effects, and long-term risk.

## Mandatory separation of claims

Every communication must state whether it concerns:

- clearer corrected or unaided vision;
- comfort or functional rehabilitation;
- slower refractive progression;
- slower axial elongation;
- temporary corneal reshaping;
- treatment of a retinal, macular, optic-nerve, lens, or ocular-surface disease;
- experimental structural restoration.

These outcomes cannot be exchanged silently.

## Required commercial disclosure

For a product or service, record:

- exact name, model, design, formulation, concentration, and manufacturer;
- regulatory jurisdiction, status, indication, and age or refractive limits;
- whether use is on-label or off-label;
- study population and duration;
- absolute outcome changes and measurement methods;
- adverse events, discontinuation, rebound, and unresolved risks;
- clinic ownership, referral fees, commissions, research funding, or inventory interest;
- total expected cost and replacement schedule;
- lower-cost and lower-risk alternatives;
- refund, stop, transfer, and data-export rights.

## Prohibited shortcuts

- Treating a CE mark, registration, or generic device listing as proof of equivalent myopia-control efficacy.
- Advertising a result from one branded lens as a class effect for all defocus lenses.
- Using unaided acuity after orthokeratology as proof of axial shortening.
- Describing refractive surgery as cure of high-myopia retinal risk.
- Generating a universal atropine concentration from heterogeneous trials.
- Calling RLRL globally settled or device-independent.
- Blaming progression on patient attitude, insufficient belief, or moral failure.
- Hiding the fact that the recommended clinic sells the product.
- Converting a limited trial result into a permanent-reversal claim.

## Patient remedy

The patient can request a corrected statement, obtain raw data, seek a second opinion, stop or transfer the plan, preserve the adverse-event record, and submit the claim to the open audit registry. Commercial pressure never changes the emergency or safety threshold.
