# Contributing

Contributions are welcome when they improve patient safety, evidence traceability, access equity, interoperability, accessibility, or scientific auditability.

A clinical or regulatory contribution should include:

- the exact source and retrieval date;
- the population and jurisdiction;
- the claimed outcome and measurement method;
- limitations, adverse events, and conflicts of interest;
- a test that fails before the change and passes afterward;
- no unsupported universalization from one product or country.

Do not submit patient-identifiable information, copyrighted full texts without permission, promotional copy disguised as evidence, or code that enables automatic diagnosis, prescription, payment, or device exposure.
